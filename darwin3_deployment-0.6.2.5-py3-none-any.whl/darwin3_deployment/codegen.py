from collections.abc import Sequence
from functools import wraps
import inspect
import json
import os
from typing import Any, Optional, Union

import numpy as np

from .ir import PhysicalPopulation
from .pops_data import PopsDataConfig, DelayRecord
from .utils import _get_pair, calculate_conv_output_shape


__all__ = ["add_to_dendrite_conv", "add_to_dendrite_full", "add_standard_connection", "add_one_to_one_connection",
           "add_trans_conv_connection", "add_output_connection", "add_connections",
           "dump_pop", "dump_input_neuron", "dump_output_neuron", "dump_delay_record"]

_distance_exceeded_flag: bool = False
_skipped_functions: set[str] = set()


def _is_within_distance(pre_pop: PhysicalPopulation, post_pop: PhysicalPopulation, max_distance=15) -> bool:
    if not isinstance(pre_pop, PhysicalPopulation):
        raise TypeError("'pre_pop' must be a PhysicalPopulation.")
    if not isinstance(post_pop, PhysicalPopulation):
        raise TypeError("'post_pop' must be a PhysicalPopulation.")
    if pre_pop.pop_position == "input":
        return True

    global _distance_exceeded_flag
    x1, y1 = pre_pop.coord
    x2, y2 = post_pop.coord
    x_distance, y_distance = abs(x1 - x2), abs(y1 - y2)
    if x_distance > max_distance:
        print(f"X-axis distance between ({x1}, {y1}) and ({x2}, {y2}) "
              f"is {x_distance}, max distance is {max_distance}.")
    if y_distance > max_distance:
        print(f"Y-axis distance between ({x1}, {y1}) and ({x2}, {y2}) "
              f"is {y_distance}, max distance is {max_distance}.")
    within_distance = x_distance <= max_distance and y_distance <= max_distance
    if not within_distance:
        _distance_exceeded_flag = True
    return within_distance


def _validate_neuron_ids(population: PhysicalPopulation, neuron_ids: Optional[Sequence[int]]) -> np.ndarray:
    if neuron_ids is None:
        neuron_ids_ = np.arange(population.size, dtype=int)
    else:
        neuron_ids_ = np.asarray(neuron_ids, dtype=int).reshape(-1)
        if not (neuron_ids_.size > 0 and np.all(neuron_ids_ >= 0)):
            raise ValueError("Neuron IDs must be a non-empty sequence of non-negative integers.")
        if neuron_ids_.max() >= population.size:
            raise ValueError(f"Neuron IDs must be within the range of the population size {population.size}.")
    return neuron_ids_


def _validate_conv_connections(weight: np.ndarray, pre_pops, post_pops, stride=1, padding=1, dilation=1):
    if weight.ndim != 4:
        raise ValueError("The weight of convolution connection must be a four-dimensional array.")
    pre_feature_map_shape, post_feature_map_shape = pre_pops[0].shape[-2:], post_pops[0].shape[-2:]
    pre_shape, post_shape = list((0,) + pre_feature_map_shape), list((0,) + post_feature_map_shape)
    for pop in pre_pops:
        if len(pop.shape) != 3:
            raise ValueError("The shape of the presynaptic population must be a "
                             "three-dimensional array (channels, height, width).")
        if pop.shape[-2:] != pre_feature_map_shape:
            raise ValueError("")
        pre_shape[0] += pop.shape[0]
    for pop in post_pops:
        if len(pop.shape) != 3:
            raise ValueError("The shape of the postsynaptic population must be a "
                             "three-dimensional array (channels, height, width).")
        if pop.shape[-2:] != post_feature_map_shape:
            raise ValueError("")
        post_shape[0] += pop.shape[0]
    post_shape = tuple(post_shape)

    expected_output_shape = calculate_conv_output_shape(pre_shape, weight.shape, stride, padding, dilation)
    if post_shape != expected_output_shape:
        raise ValueError(f"The shape of postsynaptic populations {post_shape} does not match "
                         f"the expected output shape {expected_output_shape}.")


def _validate_full_connections(weight: np.ndarray, pre_pops, post_pops):
    pre_pops_size = sum(pre_pop.size for pre_pop in pre_pops)
    post_pops_size = sum(post_pop.size for post_pop in post_pops)
    if weight.shape != (post_pops_size, pre_pops_size):
        raise ValueError(f"The shape of weight {weight.shape} does not match the expected shape "
                         f"({post_pops_size}, {pre_pops_size}).")


def _validate_populations_count(pre_pops, post_pops):
    if len(pre_pops) != len(post_pops):
        raise ValueError(f"The number of pre-synaptic populations {len(pre_pops)} does not match "
                         f"the number of post-synaptic populations {len(post_pops)}.")


def check_distance(func):
    signature = inspect.signature(func)

    @wraps(func)
    def wrapper(*args, **kwargs):
        global _distance_exceeded_flag, _skipped_functions
        bound_args = signature.bind(*args, **kwargs)
        bound_args.apply_defaults()
        all_args = bound_args.arguments
        pre_pop, post_pop = all_args.get("pre_pop"), all_args.get("post_pop")
        if pre_pop is None or post_pop is None:
            raise TypeError(f"Function '{func.__name__}' must have 'pre_pop' and 'post_pop' parameters.")
        if not _is_within_distance(pre_pop, post_pop):
            return
        if _distance_exceeded_flag:
            return
        return func(*args, **kwargs)

    return wrapper


def skip_if_flagged(func):
    def wrapper(*args, **kwargs):
        global _distance_exceeded_flag
        if _distance_exceeded_flag:
            if func.__name__ not in _skipped_functions:
                print(f"[Warning]Function '{func.__name__}' skipped.")
                _skipped_functions.add(func.__name__)
            return
        return func(*args, **kwargs)

    return wrapper


@check_distance
def add_to_dendrite_conv(weight: np.ndarray, pre_pop: PhysicalPopulation, post_pop: PhysicalPopulation,
                         stride=1, padding=1):
    """为两个神经元群添加卷积连接

    Args:
        weight: 卷积核权重矩阵
        pre_pop: 突触前神经元群
        post_pop: 突触后神经元群
        stride: 卷积步长
        padding: 卷积填充
    """
    weight_ = np.asarray(weight, dtype=int)
    if weight_.ndim != 4:
        raise ValueError("The weight of convolution connection must be a four-dimensional array.")
    if len(pre_pop.shape) != 3:
        raise ValueError("The shape of the presynaptic population must be a "
                         "three-dimensional array (channels, height, width).")
    if len(post_pop.shape) != 3:
        raise ValueError("The shape of the postsynaptic population must be a "
                         "three-dimensional array (channels, height, width).")
    h_k, w_k = weight_.shape[-2], weight_.shape[-1]
    ci, h_pre, w_pre = pre_pop.shape
    c, h, w = post_pop.shape
    dendrites = {}  # 前神经元id: [后神经元起始id, [相对起始id的偏移, ...], [对应的权重值, ...]]
    for l in range(ci):
        neu_base = l * h_pre * w_pre
        for k in range(c):
            target_base = k * h * w
            for j in range(-padding, stride * (h - 1) - padding + 1, stride):
                for i in range(-padding, stride * (w - 1) - padding + 1, stride):
                    target_id = target_base + (j + padding) // stride * w + (i + padding) // stride
                    for kj in range(h_k):
                        lj = j + kj
                        if lj < 0 or lj >= h_pre:
                            continue
                        for ki in range(w_k):
                            li = i + ki
                            if li < 0 or li >= w_pre:
                                continue
                            neu_id = neu_base + lj * w_pre + li
                            if neu_id not in dendrites:
                                dendrites[neu_id] = [target_id, [], []]
                            dendrites[neu_id][1].append(target_id - dendrites[neu_id][0])
                            dendrites[neu_id][2].append(weight_[k, l, kj, ki])
    is_neu_index_available = pre_pop.validate_neu_index(dendrites)
    for neu_id, (neu_index, neu_ids, wgts) in sorted(dendrites.items()):
        if is_neu_index_available:
            den_id = post_pop.add_dendrite(neu_ids, wgts, type=4)
            pre_pop.add_axon(neu_id, neu_index, post_pop, den_id)
        else:
            den_id = post_pop.add_dendrite([x + neu_index for x in neu_ids], wgts, type=0)
            pre_pop.add_axon(neu_id, -1, post_pop, den_id)


@check_distance
def add_to_dendrite_full(weight: np.ndarray, pre_pop: PhysicalPopulation, post_pop: PhysicalPopulation):
    """为两个神经元群添加全连接

    Args:
        weight: 全连接权重矩阵
        pre_pop: 突触前神经元群
        post_pop: 突触后神经元群
    """
    weight_ = np.asarray(weight, dtype=int)
    if weight_.ndim != 2:
        raise ValueError("The weight of full connection must be a two-dimensional array.")
    neu_ids = list(range(post_pop.size))
    is_neu_index_available = pre_pop.validate_neu_index({i: [0] for i in range(pre_pop.size)})
    connection_type, neu_index = (4, 0) if is_neu_index_available else (0, -1)
    for neu_id in range(pre_pop.size):
        den_id = post_pop.add_dendrite(neu_ids, weight_[:, neu_id].tolist(), type=connection_type)
        pre_pop.add_axon(neu_id, neu_index, post_pop, den_id)


@check_distance
def add_standard_connection(weight: np.ndarray, pre_pop: PhysicalPopulation, post_pop: PhysicalPopulation,
                            pre_neu_id: int, post_neu_ids: Sequence[int] = None):
    """添加标准连接(1 to N)

    Args:
        weight: 权重向量
        pre_pop: 突触前神经元群
        post_pop: 突触后神经元群
        pre_neu_id: 突触前神经元编号
        post_neu_ids: 突触后神经元编号

    Notes:
        - `weight` 和 `post_neu_ids` 均为向量，且长度应相同。
        - `post_neu_ids` 为 `None` 时，表示连接到突触后神经元群中的所有神经元。
    """
    weight_ = np.asarray(weight).reshape(-1)
    pre_neu_id_ = int(pre_neu_id)
    if pre_neu_id_ >= pre_pop.size or pre_neu_id_ < 0:
        raise ValueError(f"Invalid `pre_neu_id`: {pre_neu_id_}. It must be between 0 and {pre_pop.size - 1}.")
    post_neu_ids_ = _validate_neuron_ids(post_pop, post_neu_ids)
    if len(weight_) != len(post_neu_ids):
        raise ValueError(f"The length of 'weight' ({len(weight_)}) does not match "
                         f"the length of 'post_neu_ids' ({len(post_neu_ids_)}).")
    den_id = post_pop.add_dendrite(post_neu_ids_.tolist(), weight_.tolist(), type=0)
    pre_pop.add_axon(pre_neu_id_, -1, post_pop, den_id)


@check_distance
def add_one_to_one_connection(weight: Union[np.ndarray, int], pre_pop: PhysicalPopulation, post_pop: PhysicalPopulation,
                              pre_neu_ids: Sequence[int] = None, post_neu_ids: Sequence[int] = None):
    """添加一对一连接

    Args:
        weight: 连接权重
        pre_pop: 突触前神经元群
        post_pop: 突触后神经元群
        pre_neu_ids: 突触前神经元序号
        post_neu_ids: 突触后神经元序号

    Notes:
        - `pre_neu_ids` 为 `None` 时，表示连接到突触前神经元群中的所有神经元。
        - `post_neu_ids` 为 `None` 时，表示连接到突触后神经元群中的所有神经元。
        - `weight` 中元素的个数、突触前神经元序号个数、突触后神经元序号个数三者应相等
    """
    if isinstance(weight, (int, float, np.integer, np.floating)):
        weight_ = np.full(pre_pop.size, int(weight), dtype=int)
    else:
        weight_ = np.asarray(weight, dtype=int).reshape(-1)
    pre_neu_ids_ = _validate_neuron_ids(pre_pop, pre_neu_ids)
    post_neu_ids_ = _validate_neuron_ids(post_pop, post_neu_ids)
    if len(pre_neu_ids_) != len(post_neu_ids_):
        raise ValueError(f"The length of 'pre_neu_ids' ({len(pre_neu_ids_)}) does not match "
                         f"the length of 'post_neu_ids' ({len(post_neu_ids_)}).")
    if len(weight_) != len(pre_neu_ids_):
        raise ValueError(f"The length of 'weight' ({len(weight_)}) does not match "
                         f"the number of neurons ({len(pre_neu_ids_)}).")
    for i, (pre_neu_id, post_neu_id) in enumerate(zip(pre_neu_ids_, post_neu_ids_)):
        den_id = post_pop.add_dendrite([int(post_neu_id)], int(weight_[i]), share=True, type=0)
        pre_pop.add_axon(int(pre_neu_id), -1, post_pop, den_id)


@check_distance
def add_trans_conv_connection(
    weight: np.ndarray,
    pre_pop: PhysicalPopulation,
    post_pop: PhysicalPopulation,
    stride: Union[int, tuple[int, int]] = 1,
    padding: Union[int, tuple[int, int]] = 0,
    output_padding: Union[int, tuple[int, int]] = 0,
    dilation: Union[int, tuple[int, int]] = 1,
):
    """为两个神经元群添加转置卷积连接

    Args:
        weight: 转置卷积核权重矩阵
        pre_pop: 突触前神经元群
        post_pop: 突触后神经元群
        stride: 转置卷积步长
        padding: 转置卷积填充
        output_padding: 转置卷积输出填充
        dilation: 转置卷积膨胀率
    """
    if len(pre_pop.shape) != 3:
        raise ValueError(f"Expected 'pre_pop' shape to have 3 dimensions, but got {len(pre_pop.shape)}.")
    if len(post_pop.shape) != 3:
        raise ValueError(f"Expected 'post_pop' shape to have 3 dimensions, but got {len(post_pop.shape)}.")

    weight_ = np.asarray(weight, dtype=int)
    if weight_.ndim != 4:
        raise ValueError(f"Weight array must be 4-dimensional.")

    stride = _get_pair(stride)
    padding = _get_pair(padding)
    output_padding = _get_pair(output_padding)
    dilation = _get_pair(dilation)
    kernel_size = weight_.shape[-2:]
    c_i, h_i, w_i = pre_pop.shape
    c_o, h_o, w_o = post_pop.shape
    expected_h_o = (h_i - 1) * stride[0] - 2 * padding[0] + dilation[0] * (kernel_size[0] - 1) + output_padding[0] + 1
    expected_w_o = (w_i - 1) * stride[1] - 2 * padding[1] + dilation[1] * (kernel_size[1] - 1) + output_padding[1] + 1
    if (h_o, w_o) != (expected_h_o, expected_w_o):
        raise ValueError(f"Expected shape {(expected_h_o, expected_w_o)}, but got {(h_o, w_o)}.")

    dendrites = {}  # 前神经元id: [后神经元起始id, [相对起始id的偏移, ...], [对应的权重值, ...]]
    for co in range(c_o):
        for i in range(h_i):
            for j in range(w_i):
                for kh in range(kernel_size[0]):
                    for kw in range(kernel_size[1]):
                        hi = (i * stride[0]) + kh * dilation[0] - padding[0]
                        wj = (j * stride[1]) + kw * dilation[1] - padding[1]
                        if 0 <= hi < h_o and 0 <= wj < w_o:
                            for ci in range(c_i):
                                pre_id = ci * h_i * w_i + i * w_i + j
                                post_id = co * h_o * w_o + hi * w_o + wj
                                if pre_id not in dendrites:
                                    dendrites[pre_id] = [post_id, [], []]
                                dendrites[pre_id][1].append(post_id - dendrites[pre_id][0])
                                dendrites[pre_id][2].append(weight_[ci, co, kh, kw])
    is_neu_index_available = pre_pop.validate_neu_index(dendrites)
    for neu_id, (neu_index, neu_ids, wgts) in sorted(dendrites.items()):
        if is_neu_index_available:
            den_id = post_pop.add_dendrite(neu_ids, wgts, type=4)
            pre_pop.add_axon(neu_id, neu_index, post_pop, den_id)
        else:
            den_id = post_pop.add_dendrite([x + neu_index for x in neu_ids], wgts, type=0)
            pre_pop.add_axon(neu_id, -1, post_pop, den_id)
    return dendrites


@check_distance
def add_output_connection(pre_pop: PhysicalPopulation, post_pop: PhysicalPopulation):
    """添加输出连接

    Args:
        pre_pop: 突触前神经元群
        post_pop: 突触后神经元群（虚拟）

    Notes:
        突触前神经元群所在核心与输出抵达边界的距离不能超过15
    """
    if post_pop.pop_position != "output":
        raise ValueError(f"Population on core {post_pop.coord} is not a output population.")
    if pre_pop.size != post_pop.size:
        raise ValueError(f"pre_pop.size {pre_pop.size} does not match post_pop.size {pre_pop.size}.")
    for i in range(pre_pop.size):
        pre_pop.add_axon(i, -1, post_pop, i)


def add_connections(
    connection_type: str,
    weight: Optional[Union[np.ndarray, int]],
    pre_pops: Union[Sequence[PhysicalPopulation], PhysicalPopulation],
    post_pops: Union[Sequence[PhysicalPopulation], PhysicalPopulation],
    **kwargs,
):
    """添加指定类型连接

    Args:
        connection_type: 连接类型，可以是"conv"、"full"、"one_to_one"、"trans_conv"或"output"
        weight: 连接权重
        pre_pops: 若干个突触前神经元群
        post_pops: 若干个突触后神经元群
        **kwargs: 其他可选的关键字参数，用于配置特定连接的参数

    Keyword Args:
        stride (int): 卷积步长，在卷积连接中可用，默认值为1
        padding (int): 卷积填充，在卷积连接中可用，默认值为1

    Notes:
        - 连接类型为卷积时，仅支持在通道维度上切分神经元群
        - 连接类型为 "output" 时，用来给需要输出的神经元群添加轴突，权重应为 `None`
        - 连接类型为 "output" 或 "one_to_one" 时，突触前后神经元群数量应相等
    """
    if connection_type not in {"conv", "full", "one_to_one", "output", "trans_conv"}:
        raise NotImplementedError(f"'add_connections' does not support the connection type '{connection_type}'.")

    if weight is None and connection_type != "output":
        raise ValueError("'weight' cannot be None unless the connection type is 'output'.")

    pre_pops = [pre_pops] if isinstance(pre_pops, PhysicalPopulation) else pre_pops
    post_pops = [post_pops] if isinstance(post_pops, PhysicalPopulation) else post_pops

    if weight is not None:
        weight_ = np.asarray(weight, dtype=int)
    if connection_type == "conv":
        _validate_conv_connections(weight_, pre_pops, post_pops, **kwargs)
    elif connection_type == "full":
        _validate_full_connections(weight_, pre_pops, post_pops)
    elif connection_type == "one_to_one":
        _validate_populations_count(pre_pops, post_pops)
        if isinstance(weight, (int, float, np.integer, np.floating)):
            weight_ = np.full(sum(pop.size for pop in pre_pops), int(weight), dtype=int)
        else:
            weight_ = np.asarray(weight, dtype=int).reshape(-1)
    elif connection_type == "output":
        _validate_populations_count(pre_pops, post_pops)

    def _add_2d_connections(fn_connect):
        v_start = 0
        for post_pop in post_pops:
            step_v = post_pop.size
            u_start = 0
            for pre_pop in pre_pops:
                step_u = pre_pop.size
                w = weight_[v_start: v_start + step_v, u_start: u_start + step_u]
                fn_connect(w, pre_pop, post_pop, **kwargs)
                u_start += step_u
            v_start += step_v

    if connection_type == "conv":
        v_start = 0
        for post_pop in post_pops:
            step_v = post_pop.shape[0]
            u_start = 0
            for pre_pop in pre_pops:
                step_u = pre_pop.shape[0]
                w = weight_[v_start: v_start + step_v, u_start: u_start + step_u, :, :]
                add_to_dendrite_conv(w, pre_pop, post_pop, **kwargs)
                u_start += step_u
            v_start += step_v
    elif connection_type == "trans_conv":
        v_start = 0
        for pre_pop in pre_pops:
            step_v = pre_pop.shape[0]
            u_start = 0
            for post_pop in post_pops:
                step_u = post_pop.shape[0]
                w = weight_[v_start: v_start + step_v, u_start: u_start + step_u, :, :]
                add_trans_conv_connection(w, pre_pop, post_pop, **kwargs)
                u_start += step_u
            v_start += step_v
    elif connection_type == "full":
        _add_2d_connections(add_to_dendrite_full)
    elif connection_type == "one_to_one":
        start = 0
        for pre_pop, post_pop in zip(pre_pops, post_pops):
            add_one_to_one_connection(weight_[start: start + pre_pop.size], pre_pop, post_pop, **kwargs)
            start += pre_pop.size
    elif connection_type == "output":
        for pre_pop, post_pop in zip(pre_pops, post_pops):
            add_output_connection(pre_pop, post_pop)


@skip_if_flagged
def dump_pop(pop_list: Union[Sequence[PhysicalPopulation], PhysicalPopulation],
             pop_name: str, output_dir: Optional[str] = None, need_description=True,
             need_show_usage=True):
    """序列化PhysicalPopulation

    Args:
        pop_list (Sequence[PhysicalPopulation] | PhysicalPopulation): 由同一神经元群切分后得到的若干神经元群
        pop_info (dict): 存储神经元群相关数据的字典
        pop_name: pop名
        output_dir (str | None): 输出目录
        need_description: 是否需要输出描述信息
        need_show_usage: 是否需要输出节点使用率信息

    """
    pops_data_config = PopsDataConfig()
    delay_record = DelayRecord()
    pop_info = pops_data_config.get_pop_data(pop_name)
    original_dir = os.getcwd()
    if output_dir is not None:
        os.chdir(output_dir)

    pop_list = [pop_list] if isinstance(pop_list, PhysicalPopulation) else pop_list

    core_config = pop_info["core_config"]
    conf, regs, inst, inf_state, inf_param, vt, learning_param = core_config.get_core_config_value(pop_info)
    delay = regs[core_config.delay_reg[1]] if core_config.delay_reg else None

    total_pop_size = sum(pop.size for pop in pop_list)

    def _validate_array_size(array: Union[np.ndarray, int, None], name: str) -> Optional[np.ndarray]:
        if array is None:
            return None
        if isinstance(array, int):
            array = np.full(total_pop_size, array, dtype=np.int64)
        elif isinstance(array, np.ndarray) and array.size != total_pop_size:
            raise ValueError(f"{name} size ({array.size}) does not match "
                             f"the number of neurons ({total_pop_size}).")
        return array

    inf_state = _validate_array_size(inf_state, "Inference state")
    inf_param = _validate_array_size(inf_param, "Inference parameter")
    vt = _validate_array_size(vt, "Vt")
    learning_param = _validate_array_size(learning_param, "Learning parameter")

    inf_start = 0

    id_start = 0  # 输出json文件: id->coord+id
    pops_mapping = {}

    for pop in pop_list:
        # 重排神经元（有轴突、无轴突）
        core_usage = ""
        is_error = False
        pop.remove_empty_axon()
        conf[0] = (pop.size - 1) << 4  # 神经元个数寄存器[15:4] 神经元个数-1
        conf[1] = (pop.num_dendrites - 1) << 16  # 树突个数寄存器[30:16] 树突终止编号
        conf[8] = pop.weight_qa_serialize()
        if delay is not None:
            high_reg, low_reg = core_config.delay_reg
            scaled_delay = pop.size * delay
            regs[high_reg] = (scaled_delay >> 15) & 0x7fff
            regs[low_reg] = scaled_delay & 0x7fff
            delay_record.set_delay(pop.coord, [high_reg, regs[high_reg], low_reg, regs[low_reg]])
        offset = pop.coord
        pop_size = pop.size
        for i in range(pop_size):
            pops_mapping[id_start+i] = (offset[0], offset[1], i)
        id_start += pop_size
        if need_description:
            desc_path = os.path.join('.', 'desc')
            if not os.path.exists(desc_path):
                os.makedirs(desc_path)
            desc_file_path = os.path.join(desc_path, "%d-%d-desc.md" % (offset[0], offset[1]))
            with open(desc_file_path, "w") as f:
                f.write("# Axon:\n")
                axon_desc, axon_out_desc = pop.axon_description()
                f.write(axon_desc + "\n\n")
                f.write(axon_out_desc + "\n\n")
                f.write("# Dendrite:\n")
                dendrite_desc, neu_id_desc, weight_desc = pop.dendrite_description()
                f.write(dendrite_desc + "\n\n")
                f.write(neu_id_desc + "\n\n")
                f.write(weight_desc + "\n\n")

        with open("%d-%d-de.txt" % (offset[0], offset[1]), "w") as f:
            dendrite_bin = pop.dendrite_serialize()
            data_size = len(dendrite_bin)
            link_size_minus_one = (data_size - 1) & 0xffff
            conf[29] = (link_size_minus_one << 16) | link_size_minus_one
            if inf_state is not None:
                data_size += pop.size
            elif inf_param is not None:
                data_size += 4096 + pop.size
            usage = data_size / pop.dendrite_memory_size * 100
            core_usage += f"Core{pop.coord}: Dendrite memory depth {pop.dendrite_memory_size}, current data size: " \
                          f"{data_size}, usage: {usage:.2f}%."
            if data_size > pop.dendrite_memory_size:
                is_error = True
            for den_id, bin in sorted(dendrite_bin.items()):
                f.write("%012x\n" % bin)
        with open("%d-%d-ax.txt" % (offset[0], offset[1]), "w") as f:
            axon_bin = pop.axon_serialize()
            usage = len(axon_bin) / pop.axon_memory_size * 100
            core_usage += f" Axon memory depth {pop.axon_memory_size}, " \
                          f"current data size: {len(axon_bin)}, " \
                          f"usage: {usage:.2f}%"
            if len(axon_bin) > pop.axon_memory_size:
                is_error = True
            for axon_id, bin in sorted(axon_bin.items()):
                f.write("%07x\n" % bin)
        if is_error:
            core_usage = "[ERROR] " + core_usage
        else:
            core_usage = "[INFO] " + core_usage
        if need_show_usage or is_error:
            print(core_usage)
        if inf_state is not None:
            with open("%d-%d-is.txt" % (offset[0], offset[1]), "w") as f:
                num_neurons = pop.size
                for i in range(num_neurons):
                    f.write("%012x\n" % int(inf_state[inf_start + num_neurons - 1 - i]))
        if inf_param is not None:
            with open("%d-%d-ip.txt" % (offset[0], offset[1]), "w") as f:
                num_neurons = pop.size
                for i in range(num_neurons):
                    f.write("%012x\n" % int(inf_param[inf_start + num_neurons - 1 - i]))
        if learning_param is not None:
            with open("%d-%d-lp.txt" % (offset[0], offset[1]), "w") as f:
                num_neurons = pop.size
                for i in range(num_neurons):
                    f.write("%012x\n" % int(learning_param[i]))
        if vt is not None:
            with open("%d-%d-vt.txt" % (offset[0], offset[1]), "w") as f:
                num_neurons = pop.size
                for i in range(num_neurons):
                    f.write("%04x\n" % int(vt[i]))
        inf_start += pop.size
        with open("%d-%d-config.dwnc" % (offset[0], offset[1]), "w") as f:
            f.write("# core (%d, %d)\n" % (offset[0], offset[1]))
            for i in range(len(conf)):
                f.write('0 write %d %d 0x%04x 0x%08x\n' % (offset[0], offset[1], i, conf[i]))
            for i in range(len(regs)):
                f.write('0 write %d %d 0x%04x 0x%08x\n' % (offset[0], offset[1], i + 0x800, regs[i]))
            for i in range(len(inst)):
                f.write('0 write %d %d 0x%04x 0x%08x\n' % (offset[0], offset[1], i + 0x1000, inst[i]))
            f.write('0 write_ram %d %d 0x08000 %d-%d-ax.txt\n' % (offset[0], offset[1], offset[0], offset[1]))
            f.write('0 write_ram %d %d 0x10000 %d-%d-de.txt\n' % (offset[0], offset[1], offset[0], offset[1]))
            if inf_state is not None:
                f.write('0 write_ram %d %d 0x1%04x %d-%d-is.txt\n' % (
                    offset[0], offset[1], pop.inf_state_start_addr - pop.size, offset[0], offset[1]))
            if inf_param is not None:
                f.write('0 write_ram %d %d 0x1%04x %d-%d-ip.txt\n' % (
                    offset[0], offset[1], pop.inf_param_start_addr - pop.size, offset[0], offset[1]))
            if learning_param is not None:
                f.write('0 write_ram %d %d 0x1%04x %d-%d-lp.txt\n' % (
                    offset[0], offset[1], pop.learning_param_start_addr - pop.size, offset[0], offset[1]))
            if vt is not None:
                f.write('0 write_ram %d %d 0x02000 %d-%d-vt.txt\n' % (offset[0], offset[1], offset[0], offset[1]))
    file_name = pop_name + ".json"
    with open(file_name, "w") as f:
        json.dump(pops_mapping, f)
    os.chdir(original_dir)


@skip_if_flagged
def dump_input_neuron(input_pops: Union[PhysicalPopulation, Sequence[PhysicalPopulation]],
                      output_dir: str = ".", file_name: str = "input_neuron.json"):
    """将输入神经元信息导出为JSON文件

    Args:
        input_pops: 所有输入神经元群
        output_dir: 输出文件的目录，默认为当前目录
        file_name: 输出文件的名称，默认为 "input_neuron.json"
    """
    if isinstance(input_pops, PhysicalPopulation):
        input_pops = [input_pops]

    input_neuron = {}  # 前神经元序号: [0, 后神经元序号, [[x, y, 树突id], ...]]
    start_id = 0
    for input_pop in input_pops:
        if input_pop.pop_position != "input":
            raise ValueError(f"Population on core {input_pop.coord} is not an input population.")
        anaxonic_neurons = []
        for pre_neu_id, axon in input_pop._axons.items():
            if not axon:
                anaxonic_neurons.append(pre_neu_id)
                input_neuron[pre_neu_id + start_id] = []
                continue
            pre_neu_id += start_id
            post_neu_id = max(axon[0], 0)
            for axon_id in axon[1:]:
                post_pop, den_id = input_pop._axon_out[axon_id]
                if pre_neu_id not in input_neuron:
                    input_neuron[pre_neu_id] = [0, post_neu_id, []]
                input_neuron[pre_neu_id][2].append([post_pop.coord[0], post_pop.coord[1], den_id])
        start_id += input_pop.size
        if anaxonic_neurons:
            print(f"[INFO] Input population on virtual core {input_pop.coord} contains anaxonic neurons: {anaxonic_neurons}.")
    with open(os.path.join(output_dir, file_name), "w") as f:
        json.dump(input_neuron, f)


@skip_if_flagged
def dump_output_neuron(output_pops: Union[PhysicalPopulation, Sequence[PhysicalPopulation]], pop_name: str,
                       output_dir: str = ".", file_name: str = "output_neuron"):
    if isinstance(output_pops, PhysicalPopulation):
        output_pops = [output_pops]

    output_neuron = {}  # 划分后coord, 局部id -> 每层的逻辑id
    start = 0
    for output_pop in output_pops:
        # output_pop.remove_empty_axon()
        for axon_id in range(output_pop.size):
            output_neuron[f"{output_pop.coord[0]}, {output_pop.coord[1]}, {axon_id}"] = start + axon_id
        start += output_pop.size
    file_name = file_name + "_" + pop_name + ".json"
    with open(os.path.join(output_dir, file_name), "w") as f:
        json.dump(output_neuron, f)


def dump_delay_record(output_dir: str = ".", file_name: str = "delay_record.json"):
    delay_record = DelayRecord()
    with open(os.path.join(output_dir, file_name), "w") as f:
        json.dump(delay_record.delay_record, f)

