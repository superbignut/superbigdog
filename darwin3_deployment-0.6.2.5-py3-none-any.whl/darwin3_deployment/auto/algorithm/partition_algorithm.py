from abc import ABC
from abc import abstractmethod

import networkx as nx
import numpy as np


class PartitionAlgorithm(ABC):
    @abstractmethod
    def partition(self, topo_graph: nx.DiGraph) -> dict[str, list[list[int]]]:
        pass


class SimplePartitionAlgorithm(PartitionAlgorithm):
    def __init__(self, max_neurons: int = 4096):
        self.max_neurons = max_neurons

    def partition(self, topo_graph: nx.DiGraph) -> dict[str, list[list[int]]]:
        partition_dict = {}
        for u, v, data in topo_graph.edges(data=True):
            if data["type"] == "conv":
                pop_shape = topo_graph.nodes[v]["shape"]
                if len(pop_shape) != 3:
                    raise NotImplemented("Only support 2D convolutional network")
                num_neurons = int(np.prod(pop_shape))
                if num_neurons < self.max_neurons:
                    partition_dict[v] = [list(pop_shape)]
                else:
                    c, h, w = pop_shape
                    num_partitions = (num_neurons + self.max_neurons - 1) // self.max_neurons
                    channels_per_partition = (c + num_partitions - 1) // num_partitions
                    partition_dict[v] = []
                    for i in range(num_partitions):
                        partition_dict[v].append(
                            [min(channels_per_partition, c - i * channels_per_partition), h, w])
            elif data["type"] == "fc":
                pop_shape = topo_graph.nodes[v]["shape"]
                if len(pop_shape) != 1:
                    raise NotImplemented("Only support 1D fully connected network")
                num_neurons = pop_shape[0]
                if num_neurons <= self.max_neurons:
                    partition_dict[v] = [[num_neurons]]
                else:
                    num_partitions = (num_neurons + self.max_neurons - 1) // self.max_neurons
                    neurons_per_partition = (num_neurons + num_partitions - 1) // num_partitions
                    partition_dict[v] = []
                    for i in range(num_partitions):
                        partition_dict[v].append(
                            [min(neurons_per_partition, num_neurons - i * neurons_per_partition)])
        return partition_dict
