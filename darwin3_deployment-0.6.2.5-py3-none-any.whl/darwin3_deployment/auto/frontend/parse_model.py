from typing import Optional, Union

import matplotlib
from matplotlib import pyplot as plt
import networkx as nx
import numpy as np
import torch

matplotlib.use('TkAgg')


def parse_jit_model(jit_model):
    di_graph = nx.DiGraph()
    node_info: dict[str, dict] = {}

    def _getattr(module, node):
        if node.kind() == 'prim::Param':
            return module, ''
        if node.kind() == 'prim::GetAttr':
            name = node.s('name')
            obj, parent = _getattr(module, node.input().node())
            return getattr(obj, name), parent + '.' + name if len(parent) > 0 else name

    def _skip_first(iterator):
        iterator = iter(iterator)
        next(iterator)
        return iterator

    def _get_value_index(value: torch.Value, node: torch.Node):
        for i, _value in enumerate(node.inputs()):
            if _value == value:
                return i
        raise KeyError(f"Node {node} no such value")

    def _get_constant(_value: torch.Value):
        if _value.node().kind() == "prim::ListConstruct":
            return [_get_constant(v) for v in _value.node().inputs()]
        elif _value.node().kind() == "prim::Constant":
            return _value.node().i("value")

    def _get_attribute_as_numpy(module, attr_name: str) -> Optional[np.ndarray]:
        attr = getattr(module, attr_name, None)
        return attr.detach().numpy() if attr is not None else None

    def _traverse(module: torch.ScriptModule, module_name: str, value: Union[torch.Value, int], last_node, *args):
        try:
            graph = getattr(module, "graph", None)
        except RuntimeError:
            return
        if isinstance(value, int):
            value = list(graph.inputs())[value]
        old_name = last_node[0]
        for use in value.uses():  # 遍历所有使用value的node
            last_node[0] = old_name
            node = use.user

            if node.kind() == "aten::_convolution":
                module_name_list = module_name.split(".")
                if module_name_list[-1] == "conv_module":
                    module_name = module_name_list[-2]
                if module_name in di_graph.nodes():
                    di_graph.add_edge(last_node[0], module_name, index=_get_value_index(value, node))
                    last_node[0] = module_name
                    continue
                di_graph.add_edge(last_node[0], module_name, index=_get_value_index(value, node))
                last_node[0] = module_name
                values = list(node.inputs())
                node_info[module_name] = {
                    "weight": _get_attribute_as_numpy(module, "weight"),
                    "bias": _get_attribute_as_numpy(module, "bias"),
                    "type": "conv",
                    "stride": _get_constant(values[3]),
                    "padding": _get_constant(values[4]),
                    "dilation": _get_constant(values[5]),
                }
            elif node.kind() == "aten::linear":
                module_name_list = module_name.split(".")
                if module_name_list[-1] == "fc_module":
                    module_name = module_name_list[-2]
                if module_name in di_graph.nodes():
                    di_graph.add_edge(last_node[0], module_name, index=_get_value_index(value, node))
                    last_node[0] = module_name
                    continue
                di_graph.add_edge(last_node[0], module_name, index=_get_value_index(value, node))
                last_node[0] = module_name
                node_info[module_name] = {
                    "weight": _get_attribute_as_numpy(module, "weight"),
                    "bias": _get_attribute_as_numpy(module, "bias"),
                    "type": "fc",
                }
            elif node.kind() == "prim::CallMethod" and node.s("name") == "forward":
                input_value = node.inputs()
                first_value = next(input_value)
                if first_value.node() in graph.nodes():  # first_value定义在当前graph中
                    if first_value.node().kind() == "prim::GetAttr":
                        submodule, submodule_name = _getattr(module, first_value.node())
                    else:
                        raise NotImplementedError()
                else:  # first_value由参数传入
                    for index, element in enumerate(graph.inputs()):
                        if element == first_value:
                            submodule, submodule_name = _getattr(args[0], args[index].node())
                            break
                    else:
                        raise RuntimeError("not found first_value.")
                submodule_name = ".".join([module_name, submodule_name]) if module_name else submodule_name
                index = _get_value_index(value, node)
                parameters = list(node.inputs())[1:]
                _traverse(submodule, submodule_name, index, last_node, module, *parameters)
            elif node.kind() == "prim::Return":
                continue

            for output_value in node.outputs():
                _traverse(module, module_name, output_value, last_node, *args)

    def parse_model(model):
        graph = model.graph
        iter_input = _skip_first(graph.inputs())
        for index, _ in enumerate(iter_input):
            di_graph.add_node(f"input{index}")
            _traverse(model, "", index + 1, [f"input{index}"])

    parse_model(jit_model)

    pos = nx.nx_agraph.graphviz_layout(di_graph, prog='dot')
    plt.figure(figsize=(6, 8))
    nx.draw(di_graph, pos, with_labels=True, node_size=100, node_color='lightblue', font_size=10, arrows=True)
    # edge_labels = nx.get_edge_attributes(di_graph, 'index')  # 获取边的 'index' 属性
    # nx.draw_networkx_edge_labels(di_graph, pos, edge_labels=edge_labels, font_size=8)
    plt.title('Directed Graph Visualization')
    plt.show()

    return di_graph, node_info


if __name__ == '__main__':
    jit_model = torch.jit.load("jit_model_with_fc.pth")
    di_graph = parse_jit_model(jit_model)
