from enum import Enum
from enum import Flag
from typing import Union

from ..utils import gen_scale_word


class DInst:
    DEFAULT_BW = 16
    bin_formats = (
        ('opcode', 5, 11),
        ('rs', 4, 7),
        ('rt', 4, 3),
    )

    def __init__(self, opcode):
        self.opcode = opcode

    @property
    def operands(self) -> list:
        raise NotImplementedError

    def serialize(self):
        return gen_scale_word(self)

    @staticmethod
    def get_enum_value(value, enum_class):
        if isinstance(value, enum_class):
            return value.value
        elif int(value) in enum_class._value2member_map_:
            return int(value)
        else:
            raise ValueError("invalid enum value")

    @staticmethod
    def get_enum(value, enum_class):
        if isinstance(value, enum_class):
            return value
        else:
            return enum_class._value2member_map_[int(value)]


class ADD(DInst):
    bin_formats = (
        ('opcode', 5, 11),
        ('rs', 4, 7),
        ('rt', 4, 3),
        ('ns', 1, 2),
    )

    def __init__(self, rs, rt, ns: int):
        super().__init__(opcode=0b00000)
        self.rs = rs
        self.rt = rt
        self.ns = int(bool(ns))

    def __str__(self):
        return f"ADD r{self.rs}, r{self.rt}, ns={self.ns}"

    @property
    def operands(self) -> list:
        return [self.rs, self.rt]


class SUB(DInst):
    bin_formats = (
        ('opcode', 5, 11),
        ('rs', 4, 7),
        ('rt', 4, 3),
        ('ns', 1, 2),
    )

    def __init__(self, rs, rt, ns: int = True):
        super().__init__(opcode=0b00001)
        self.rs = rs
        self.rt = rt
        self.ns = int(bool(ns))

    def __str__(self):
        return f"SUB r{self.rs}, r{self.rt}, ns={self.ns}"

    @property
    def operands(self) -> list:
        return [self.rs, self.rt]


class MUL(DInst):
    bin_formats = (
        ('opcode', 5, 11),
        ('rs', 4, 7),
        ('rt', 4, 3),
        ('qf', 1, 2),
        ('rq', 2, 0),
    )

    class QF(Enum):
        GLOBAL = 0
        REGISTER = 1

    def __init__(self, rs, rt, qf: Union[QF, int], rq):
        super().__init__(opcode=0b00010)
        self.rs = rs
        self.rt = rt
        self.qf = self.get_enum_value(qf, self.QF)
        self.rq = rq

    def __str__(self):
        return f"MUL r{self.rs}, r{self.rt}"

    @property
    def operands(self) -> list:
        return [self.rs, self.rt]


class ADDI(DInst):
    bin_formats = (
        ('opcode', 5, 11),
        ('rs', 4, 7),
        ('imme', 7, 0),
    )

    def __init__(self, rs, imme):
        super().__init__(opcode=0b00011)
        self.rs = rs
        self.imme = imme
        if self.imme & 0b100_0000:
            self.imme |= -1 << 7
    
    def __str__(self):
        return f"ADDI r{self.rs}, {self.imme}"

    @property
    def operands(self) -> list:
        return [self.rs]


class SFTI(DInst):
    bin_formats = (
        ('opcode', 5, 11),
        ('rs', 4, 7),
        ('sf', 1, 6),
        ('ns', 1, 4),
        ('imme', 4, 0),
    )

    class SF(Enum):
        LEFT = 0
        RIGHT = 1

    def __init__(self, rs, sf: Union[SF, int], ns: int, imme):
        super().__init__(opcode=0b00100)
        self.rs = rs
        self.sf = self.get_enum_value(sf, self.SF)
        self.ns: bool = bool(ns)
        self.imme = imme
    
    def __str__(self):
        return f"SFTI r{self.rs}, sf={self.SF(self.sf).name}, ns={self.ns}, {self.imme}"

    @property
    def operands(self) -> list:
        return [self.rs]


class CMP(DInst):
    bin_formats = (
        ('opcode', 5, 11),
        ('rs', 4, 7),
        ('rt', 4, 3),
        ('func', 3, 0),
    )

    class Func(Enum):
        GE = 0
        EQ = 1
        GE_0 = 2
        EQ_0 = 3

    def __init__(self, rs, rt, func: Union[Func, int]):
        super().__init__(opcode=0b00101)
        self.rs = rs
        self.rt = rt
        self.func = self.get_enum_value(func, self.Func)

    def __str__(self):
        return f"CMP r{self.rs}, r{self.rt}, func={self.Func(self.func).name}"

    @property
    def operands(self) -> list:
        return [self.rs, self.rt]


class JC(DInst):
    bin_formats = (
        ('opcode', 5, 11),
        ('cmpf', 1, 10),
        ('cmpr', 1, 9),
        ('addr', 7, 0),
    )

    def __init__(self, cmpf: int, cmpr: int, addr, offset=0):
        super().__init__(opcode=0b00110)
        self.cmpf = int(bool(cmpf))
        self.cmpr = int(bool(cmpr))
        self.addr = addr
        self.offset = offset

    def __str__(self):
        return f"JC cmpf={self.cmpf}, cmpr={self.cmpr}, addr={self.addr}"

    @property
    def operands(self) -> list:
        return []


class SA(DInst):
    bin_formats = (
        ('opcode', 5, 11),
        ('hlf', 1, 10),
        ('arf', 1, 9),
        ('addr', 8, 0),
    )

    class HLF(Enum):
        LOW = 0
        HIGH = 1

    class ARF(Enum):
        NEURON = 0
        DENDRITE = 1

    def __init__(self, hlf: Union[HLF, int], arf: Union[ARF, int], addr):
        super().__init__(opcode=0b00111)
        self.hlf = self.get_enum_value(hlf, self.HLF)
        self.arf = self.get_enum_value(arf, self.ARF)
        self.addr = addr

    def __str__(self):
        return f"SA hlf={self.HLF(self.hlf).name}, arf={self.ARF(self.arf).name}, {self.addr}"

    @property
    def operands(self) -> list:
        return []


class TS(DInst):
    bin_formats = (
        ('opcode', 5, 11),
        ('ls', 1, 10),
        ('arf', 1, 9),
        ('rd', 4, 0),
    )

    class LS(Enum):
        LOAD = 0
        STORE = 1

    class ARF(Enum):
        NEURON = 0
        DENDRITE = 1

    def __init__(self, ls: Union[LS, int], arf: Union[ARF, int], rd):
        super().__init__(opcode=0b01000)
        self.ls = self.get_enum_value(ls, self.LS)
        self.arf = self.get_enum_value(arf, self.ARF)
        self.rd = rd

    def __str__(self):
        return f"TS ls={self.LS(self.ls).name}, arf={self.ARF(self.arf).name}, rd={self.rd}"

    @property
    def operands(self) -> list:
        return [self.rd]


class MOV(DInst):
    """ Move, R[RS] = R[RT]
    """
    def __init__(self, rs, rt):
        super().__init__(opcode=0b01001)
        self.rs = rs
        self.rt = rt

    def __str__(self):
        return f"MOV r{self.rs}, r{self.rt}"

    @property
    def operands(self) -> list:
        return [self.rs, self.rt]


class LOGIC(DInst):
    """ Logic 
    """
    bin_formats = (
        ('opcode', 5, 11),
        ('rs', 4, 7),
        ('rt', 4, 3),
        ('func', 3, 0),
    )

    class FUNC(Enum):
        AND = 0
        OR = 1
        XOR = 2
        NOT = 3
        NAND = 4
        NOR = 5
        XNOR = 6

    def __init__(self, rs, rt, func: Union[FUNC, int]):
        super().__init__(opcode=0b01010)
        self.rs = rs
        self.rt = rt
        self.func = self.get_enum_value(func, self.FUNC)

    def __str__(self):
        return f"LOGIC r{self.rs}, r{self.rt}"

    @property
    def operands(self) -> list:
        return [self.rs, self.rt]


class STORE(DInst):
    bin_formats = (
        ('opcode', 5, 11),
        ('rs', 4, 7),
        ('rt', 4, 3),
        ('func', 3, 0),
    )  

    def __init__(self, rs, rt, push=True, func=0):
        super().__init__(opcode=0b01011)
        self.rs = rs
        self.rt = rt
        self.push = push
        self.func = func

    def __str__(self):
        return f"STORE r{self.rs}, r{self.rt}"

    @property
    def operands(self) -> list:
        return [self.rs, self.rt]


class LOAD(DInst):
    bin_formats = (
        ('opcode', 5, 11),
        ('rs', 4, 7),
        ('rt', 4, 3),
        ('func', 3, 0),
    )

    def __init__(self, rs, rt, pop=True, select=0):
        super().__init__(opcode=0b01100)
        self.rs = rs
        self.rt = rt
        self.pop = pop
        self.select = select

    def __str__(self):
        return f"LOAD r{self.rs}, r{self.rt}"

    @property
    def operands(self) -> list:
        return [self.rs, self.rt]


class SP(DInst):
    bin_formats = (
        ('opcode', 5, 11),
        ('rs', 4, 7),
        ('rt', 4, 3),
        ('func', 3, 0),
    )

    def __init__(self, rs, rt, sp=False, imme=False, mse8=False):
        super().__init__(opcode=0b01101)
        self.rs = rs
        self.rt = rt
        self.func = [sp, imme, mse8]
        self.sp, self.imme, self.mse8 = sp, imme, mse8

    def __str__(self):
        return f"SP r{self.rs}, r{self.rt}, func={self.func}"

    @property
    def operands(self) -> list:
        return [self.rs, self.rt]


class WMOV(DInst):
    bin_formats = (
        ('opcode', 5, 11),
        ('rs', 4, 7),
        ('rt', 4, 3),
        ('func', 3, 0),
    )

    def __init__(self, rs, rt, func):
        super().__init__(opcode=0b01110)
        self.rs = rs
        self.rt = rt
        self.func = func

    def __str__(self):
        return f"WMOV r{self.rs}, r{self.rt}, func={self.func}"

    @property
    def operands(self) -> list:
        return [self.rs, self.rt]


class ADDA(DInst):
    bin_formats = (
        ('opcode', 5, 11),
        ('rs', 4, 7),
        ('imme', 7, 0),
    )

    def __init__(self, rs, imme):
        super().__init__(opcode=0b01111)
        self.rs = rs
        self.imme = imme

    def __str__(self):
        return f"ADDA r{self.rs}, imme={self.imme}"

    @property
    def operands(self) -> list:
        return [self.rs]


class LSIS(DInst):
    bin_formats = (
        ('opcode', 5, 11),
        ('ls', 1, 10),
        ('nph', 8, 0),
    )

    class LS(Enum):
        LOAD = 0
        STORE = 1

    class REG:
        rmsb16 = 0b1000_0000
        Vt = 0b0100_0000
        Vth = 0b0010_0000
        I = 0b0001_0000
        rpd = 0b0000_1000
        wgtsum = 0b0000_0100
        res = 0b0000_0010
        rand = 0b0000_0001

    def __init__(self, ls: Union[LS, int], nph):
        super().__init__(0b10000)
        self.ls = self.get_enum_value(ls, self.LS)
        self.ls_enum = self.get_enum_value(ls, self.LS)
        self.nph = nph
        # TODO: use more direct representation
        # or let user to set later
        self.rmsb16 = nph & 0b1000_0000 != 0
        self.c_vt = nph & 0b0100_0000 != 0
        self.c_vth = nph & 0b0010_0000 != 0
        self.c_i = nph & 0b0001_0000 != 0
        self.c_rpd = nph & 0b0000_1000 != 0
        self.c_wgtsum = nph & 0b0000_0100 != 0
        self.c_res = nph & 0b0000_0010 != 0
        self.c_rand = nph & 0b0000_0001 != 0
        if self.ls == self.LS.STORE.value and self.c_wgtsum:
            print("[WARN] LSIS Store weight sum may lead to undesired results.")

    def __str__(self):
        return f"LSIS {self.ls_enum.name}, nph={self.nph}"

    @property
    def operands(self) -> list:
        reg = []
        mask = 0b100_0000
        for i in range(7):
            if self.nph & mask:
                reg.append(i)
            mask >>= 1
        return reg


class UPTVT(DInst):
    bin_formats = (
        ('opcode', 5, 11),
        ('fcs', 1, 10),
        ('fcph', 2, 0),
    )

    def __init__(self, fcs, fcph):
        super().__init__(opcode=0b10001)
        self.fcs = fcs
        self.fcph = fcph

    def __str__(self):
        return f"UPTVT fcs={self.fcs}, fcph={self.fcph}"

    @property
    def operands(self) -> list:
        return []


class UPTIS(DInst):
    bin_formats = (
        ('opcode', 5, 11),
        ('unph', 3, 8),
        ('fcph', 3, 0),
    )

    def __init__(self, unph, fcph):
        super().__init__(opcode=0b10010)
        self.unph = unph
        self.fcph = fcph

        self.u_vth = unph & 0b001 != 0
        self.u_i = unph & 0b010 != 0
        self.u_res = unph & 0b100 != 0

        self.c_p2 = fcph & 0b001 != 0
        self.c_p3 = fcph & 0b010 != 0
        self.c_p4 = fcph & 0b100 != 0

    def __str__(self):
        return f"UPTIS unph={self.unph}, fcph={self.fcph}"

    @property
    def operands(self) -> list:
        return []


class LSIP(DInst):
    bin_formats = (
        ('opcode', 5, 11),
        ('ls', 1, 10),
        ('pos', 1, 6),
        ('nph', 6, 0),
    )

    class LS(Enum):
        LOAD = 0
        STORE = 1

    def __init__(self, ls: Union[LS, int], pos, nph: set):
        super().__init__(opcode=0b10011)
        self.ls = self.get_enum_value(ls, self.LS)
        self.ls_enum = self.get_enum(ls, self.LS)
        self.pos = pos
        self.u_par = reversed([i in nph for i in range(6)])
        self.nph = int(''.join(map(str, map(int, self.u_par))), 2)

    def __str__(self):
        return f"LSIP ls={self.ls_enum.name}, pos={self.pos}, {self.nph}"

    @property
    def operands(self) -> list:
        reg = []
        mask = 0b00_0011
        for i in range(3):
            if self.nph & mask:
                reg.append(i + 13)
            mask <<= 2
        return reg


class LSLS(DInst):
    bin_formats = (
        ('opcode', 5, 11),
        ('ls', 1, 10),
        ('pre', 1, 8),
        ('nph', 8, 0),
    )

    class LS(Enum):
        LOAD = 0
        STORE = 1

    def __init__(self, ls: Union[LS, int], pre: bool, nph: int):
        super().__init__(opcode=0b10100)
        self.ls = self.get_enum_value(ls, self.LS)
        self.pre = pre
        self.nph = nph

    def __str__(self):
        return f"LSLS ls={self.ls.name}, pre={self.pre}, {self.nph}"

    @property
    def operands(self) -> list:
        reg = []
        masks = [0b0010_0001, 0b0100_0100, 0b0000_0010, 0b0000_1000, 0b1001_0000]
        for i, mask in enumerate(masks):
            if self.nph & mask:
                reg.append(i + 8)
        return reg


class UPTLS(DInst):
    bin_formats = (
        ('opcode', 5, 11),
        ('unph', 5, 6),
    )

    class UNPH(Flag):
        PRT1A_X = 0b0_0001
        PRT1B_X = 0b0_0010
        PRT1A_Y = 0b0_0100
        PRT1B_Y = 0b0_1000
        PRT_R = 0b1_0000

    def __init__(self, unph):
        super().__init__(opcode=0b10101)
        self.unph = unph

    def __str__(self):
        flag = []
        for f in list(self.UNPH):
            if self.unph | f.value:
                flag.append(f.name)
        return f"UPTLS unph={'|'.join(flag)}"

    @property
    def operands(self) -> list:
        reg = []
        masks = [0b0_0001, 0b0_0100, 0b0_0010, 0b0_1000, 0b1_0000]
        for i, mask in enumerate(masks):
            if self.unph & mask:
                reg.append(i + 8)
        return reg


class LSSYN(DInst):
    bin_formats = (
        ('opcode', 5, 11),
        ('ls', 1, 10),
    )

    class LS(Enum):
        LOAD = 0
        STORE = 1

    def __init__(self, ls: LS):
        super().__init__(opcode=0b10110)
        self.ls = self.get_enum_value(ls, self.LS)

    def __str__(self):
        return f"LSSYN ls={self.LS(self.ls).name}"

    @property
    def operands(self) -> list:
        return [7]


class UPTSYN(DInst):
    bin_formats = (
        ('opcode', 5, 11),
        ('pno', 4, 7),
        ('nph', 7, 0),
    )

    # TODO: one-hot coding
    class NPH(Flag):
        PRT0_X = 0b00_0001
        PRT1A_X = 0b00_0010
        PRT1B_X = 0b00_0100
        PRT0_Y = 0b00_1000
        PRT1A_Y = 0b00_1000
        PRT1B_Y = 0b01_0000
        PRT_R = 0b10_0000

    def __init__(self, pno, nph: Union[NPH, int]):
        super().__init__(opcode=0b10111)
        self.pno = pno
        self.nph = self.get_enum_value(nph, self.NPH)

    def __str__(self):
        flag = []
        for f in list(self.NPH):
            if self.nph | f.value:
                flag.append(f.name)
        return f"UPTSYN pno={self.pno}, nph={'|'.join(flag)}"

    @property
    def operands(self) -> list:
        reg = []
        masks = [0b000_0011, 0b001_1000, 0b000_0100, 0b010_0000, 0b100_0000]
        for i, mask in enumerate(masks):
            if self.nph & mask:
                reg.append(i + 8)
        return reg


class GSPRS(DInst):
    bin_formats = (
        ('opcode', 5, 11),
        ('rs', 4, 7),
        ('gspm', 2, 5),
        ('rstn', 1, 4),
        ('gsp', 1, 3),
        ('vcp', 1, 2),
        ('rsm', 2, 0),
    )

    class GSPM(Flag):
        DEFAULT = 0b00
        NEURON_INDEX = 0b01
        AXON_INDEX = 0b10

    class RSM(Enum):
        NOP = 0
        ZERO = 1
        SUB_VTH = 2
        SUB_VTDEC = 3

    def __init__(self, rs, gspm: GSPM, rstn: int, gsp: int, vcp: int, rsm: Union[RSM, int]):
        super().__init__(opcode=0b11000)
        self.rs = rs
        self.gspm = self.get_enum_value(gspm, self.GSPM)
        self.rstn = int(bool(rstn))
        self.gsp = int(bool(gsp))
        self.vcp = int(bool(vcp))
        self.rsm = self.get_enum_value(rsm, self.RSM)

    def __str__(self):
        flag = []
        for f in list(self.GSPM):
            if self.gspm & f.value:
                flag.append(f.name)
        return (f"GSPRS r{self.rs}, gspm={self.GSPM(self.gspm)}, "
                f"rstn={self.rstn}, gsp={self.gsp}, vcp={self.vcp}, "
                f"rsm={self.RSM(self.rsm).name}")

    @property
    def operands(self) -> list:
        reg = set()
        if self.gspm & 0b11:
            reg.add(self.rs)
        if self.rstn == 0:
            reg.add(0)
            if self.vcp == 1 or self.rsm == 2:
                reg.add(1)
        if self.gsp == 1 and self.vcp == 1:
            reg.union([1, 2])
        return list(reg)


class NPC(DInst):
    bin_formats = (
        ('opcode', 5, 11),
    )

    def __init__(self):
        super().__init__(opcode=0b11001)

    def __str__(self):
        return "NPC"

    @property
    def operands(self) -> list:
        return []


class STATE(DInst):
    bin_formats = (
        ('opcode', 5, 11),
        ('rs', 4, 7),
        ('rt', 4, 3),
        ('func', 3, 0),
    )

    class Func(Enum):
        NEURON = 0b100
        DENDRITE = 0b000

    def __init__(self, rs, rt, func: Func):
        super().__init__(opcode=0b11010)
        self.rs = rs
        self.rt = rt
        self.func = self.get_enum_value(func, self.Func)

    def __str__(self):
        return f"STATE r{self.rs}, r{self.rt}, func={self.Func(self.func).name}"

    @property
    def operands(self) -> list:
        return [self.rs, self.rt]


class BUBBLE(DInst):
    bin_formats = (
    )

    def __init__(self):
        super().__init__(opcode=-1)
    
    def __str__(self):
        return f"bubble-zzz"

    @property
    def operands(self) -> list:
        return []
