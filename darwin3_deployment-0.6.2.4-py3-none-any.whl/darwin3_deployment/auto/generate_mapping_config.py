from collections import OrderedDict
from queue import Queue

import networkx as nx
import torch
import yaml

from darwin3_deployment.utils import calculate_conv_output_shape

from .algorithm import SimplePartitionAlgorithm
from .algorithm import SimplePlacementAlgorithm
from .frontend import parse_jit_model


class CustomDumper(yaml.SafeDumper):
    def increase_indent(self, flow=False, indentless=False):
        return super(CustomDumper, self).increase_indent(flow, False)


def is_three_dimensional_list(lst):
    if not isinstance(lst, list):
        return False
    if not lst:     # lst为空
        return False
    if not isinstance(lst[0], list):
        return False
    if not lst[0]:  # lst[0]为空
        return False
    if not isinstance(lst[0][0], list):
        return False
    return True


def list_representer(dumper, data):
    if is_three_dimensional_list(data):     # 最外层列表使用块样式
        return dumper.represent_sequence('tag:yaml.org,2002:seq', data, flow_style=False)
    else:                                   # 内层列表使用流样式
        return dumper.represent_sequence('tag:yaml.org,2002:seq', data, flow_style=True)


def dict_representer(dumper, data):
    return dumper.represent_dict(data.items())


CustomDumper.add_representer(list, list_representer)
CustomDumper.add_representer(OrderedDict, dict_representer)


def convert_graph(computation_graph: nx.DiGraph, quant_info: dict, input_shapes: tuple[tuple[int]]) -> nx.DiGraph:
    # 从计算图生成网络拓扑图topo_graph，topo_graph的顶点表示神经元群，边表示算子对应的连接
    topo_graph = nx.DiGraph()
    nodes_to_visit = Queue()
    visited = set()

    # 处理输入
    for i, input_shape in enumerate(input_shapes):
        pop_input = f"input{i}"
        if pop_input not in computation_graph.nodes:
            raise ValueError(f"Number of inputs mismatched")
        nodes_to_visit.put(pop_input)
        visited.add(pop_input)
        topo_graph.add_node(pop_input, shape=input_shape)

    while not nodes_to_visit.empty():
        cur_pop = nodes_to_visit.get()
        for successor in computation_graph.successors(cur_pop):
            op_data = quant_info[successor]
            weight_shape = op_data["weight"].shape
            if op_data["type"] == "conv":
                new_shape = calculate_conv_output_shape(
                    topo_graph.nodes[cur_pop]["shape"],
                    weight_shape,
                    op_data["stride"],
                    op_data["padding"],
                    op_data["dilation"],
                )
            else:  # 全连接
                new_shape = (weight_shape[0],)
            topo_graph.add_node(successor, shape=new_shape)  # 添加突触后神经元群
            topo_graph.add_edge(cur_pop, successor, type=op_data["type"])
            if successor not in visited:
                visited.add(successor)
                nodes_to_visit.put(successor)

    return topo_graph


def generate_mapping_config(model_path, input_shapes=((3, 32, 32),), core_grid=(24, 24),  output_path=None):
    if output_path is None:
        output_path = "config_generate.yaml"
    model = torch.jit.load(model_path)
    computation_graph, quant_info = parse_jit_model(model)
    topo_graph = convert_graph(computation_graph, quant_info, input_shapes)
    partition = SimplePartitionAlgorithm().partition(topo_graph)
    placement = SimplePlacementAlgorithm().place(partition, core_grid)
    config = {
        "input": [[list(input_shape), [-1, i]] for i, input_shape in enumerate(input_shapes)],
        "hidden": placement,
        "output": [[[], [], "output layer name?"]],
        "core_config": {"default": "config1"},
    }
    with open(output_path, 'w', encoding='utf-8') as f:
        yaml.dump(OrderedDict(config), f, Dumper=CustomDumper)


if __name__ == "__main__":
    import time
    path = ".".join([time.strftime("%Y%m%d-%H%M%S"), "yaml"])
    generate_mapping_config("jit_model_large.pth", output_path=path)
