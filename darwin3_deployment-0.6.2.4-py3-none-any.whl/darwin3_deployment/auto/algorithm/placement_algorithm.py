from abc import ABC
from abc import abstractmethod


class PlacementAlgorithm(ABC):
    @abstractmethod
    def place(self, partitions: dict[str, list[list[int]]], core_grid: tuple[int, int]) -> list[tuple[int, int]]:
        pass


class SimplePlacementAlgorithm(PlacementAlgorithm):
    def __init__(self, curve_type='zigzag'):
        self.curve_type = curve_type

    def place(self, partitions: dict[str, list], core_grid: tuple[int, int] = (24, 24)) -> dict[str, list]:
        if self.curve_type == 'zigzag':
            return self.place_zigzag(partitions, core_grid)
        else:
            raise ValueError("Unsupported curve type")

    def place_zigzag(self, partitions: dict[str, list], core_grid: tuple[int, int]) -> dict[str, list]:
        grid_height, grid_width = core_grid
        core_count = 1  # 跳过坐标为(0, 0)的核心

        i = 0
        res = {}
        for name, pop_list in partitions.items():
            res[name] = []
            for pop in pop_list:
                row = core_count // grid_width
                if row % 2 == 0:
                    col = core_count % grid_width
                else:
                    col = grid_width - 1 - (core_count % grid_width)
                if row < grid_height:
                    res[name].append([pop, [row, col]])
                    core_count += 1
                else:
                    raise ValueError("Not enough cores to place all partitions.")
                i += 1
        return res
