import importlib
import json
import os
from queue import Queue
import time

import networkx as nx
import numpy as np
import torch
from tqdm import tqdm
import yaml

from darwin3_deployment.codegen import *
from darwin3_deployment.ir import PhysicalPopulation
from darwin3_deployment.pops_data import PopsDataConfig
from darwin3_deployment.utils import calculate_conv_output_shape

from .frontend import parse_jit_model


def parse_config_file(file_path):
    _, file_extension = os.path.splitext(file_path)
    with open(file_path, 'r', encoding='utf-8') as file:
        if file_extension == '.json':
            return json.load(file)
        elif file_extension == '.yaml':
            return yaml.safe_load(file)
        else:
            raise ValueError("Unsupported file format. Please use 'json' or 'yaml'.")


def build(model_path, config_file_path, core_config_module="user_configs", output_dir=None,
          need_description=False, need_show_usage=False):
    config = parse_config_file(config_file_path)
    required_keys = ["input", "hidden", "output", "core_config"]
    for key in required_keys:
        if key not in config:
            raise ValueError(f"Expected '{key}' in {config_file_path}.")

    print("Loading model...")
    model = torch.jit.load(model_path, map_location="cpu")
    print("Parsing model...")
    computation_graph, pops_info = parse_jit_model(model)

    # 获取寄存器和指令设置
    print("Loading core configuration...")
    for pop_name, core_config_name in config["core_config"].items():
        config_list = core_config_name.split(".")
        if len(config_list) > 1:
            config_module, config_name = ".".join(config_list[:-1]), config_list[-1]
        else:
            config_module, config_name = core_config_module, config_list[0]
        user_config_module = importlib.import_module(config_module)
        core_config = getattr(user_config_module, config_name, None)
        if core_config is None:
            raise ValueError(f"Configuration '{config_name}' not found in module '{config_module}'")
        if pop_name == "default":
            for pop in pops_info:
                pops_info[pop]["core_config"] = core_config
        elif pop_name in pops_info:
            pops_info[pop_name]["core_config"] = core_config
        else:
            raise ValueError("Invalid population name in core config setting")
    for pop_name, pop_info in pops_info.items():
        if "core_config" not in pop_info:
            raise ValueError(f"{pop_name} need CoreConfig")

    # 从计算图生成网络拓扑图topo_graph，topo_graph的顶点表示神经元群，边表示算子对应的连接
    populations_dict: dict[str, list[PhysicalPopulation]] = {}
    topo_graph = nx.DiGraph()
    nodes_to_visit = Queue()
    visited = set()

    # 处理输入
    input_populations_list = []
    for i, pop_config in enumerate(config["input"]):
        input_pop_name = f"input{i}"
        if input_pop_name not in computation_graph.nodes:
            raise ValueError(f"Number of inputs mismatched")
        nodes_to_visit.put(input_pop_name)
        visited.add(input_pop_name)
        topo_graph.add_node(input_pop_name, shape=pop_config[0])
        input_pop = PhysicalPopulation(shape=pop_config[0], coord=pop_config[1], pop_position="input")
        populations_dict[input_pop_name] = [input_pop]
        input_populations_list.append(input_pop)

    while not nodes_to_visit.empty():
        cur_pop = nodes_to_visit.get()
        for successor in computation_graph.successors(cur_pop):
            op_data = pops_info[successor]
            weight_shape = op_data["weight"].shape
            if op_data["type"] == "conv":
                new_shape = calculate_conv_output_shape(
                    topo_graph.nodes[cur_pop]["shape"],
                    weight_shape,
                    op_data["stride"],
                    op_data["padding"],
                    op_data["dilation"],
                )
            else:   # 全连接
                new_shape = (weight_shape[0],)
            topo_graph.add_node(successor, shape=new_shape)   # 添加突触后神经元群
            topo_graph.add_edge(cur_pop, successor, type=op_data["type"])
            if successor not in visited:
                visited.add(successor)
                nodes_to_visit.put(successor)

    # 更新pops_info
    for q_item, info in pops_info.items():
        if not hasattr(model, q_item):
            raise ValueError(f"Model has no '{q_item}'")
        module = getattr(model, q_item)
        for var_name in pops_info[q_item]["core_config"].bound_variable_set:
            if var_name not in info:
                info[var_name] = getattr(module, var_name).detach().numpy()
        if info["type"] == "conv" and "bias" in info:
            c, h, w = topo_graph.nodes[q_item]["shape"]
            info["bias"] = np.tile(info["bias"].reshape(c, 1, 1), (1, h, w))
    PopsDataConfig().set_pops_data(pops_info)

    # 根据切分和映射结果构建PhysicalPopulation
    for name, populations in config["hidden"].items():
        if name not in topo_graph.nodes():
            raise ValueError("Invalid layer name")
        num_neurons = 0
        continuous_populations = []
        for i, population in enumerate(populations):
            shape, coord = population[0], population[1]
            n = np.prod(shape)
            if n > 4096:
                raise ValueError(f"A neuromorphic core can support a maximum of 4096 neurons, now got {n} neurons.")
            num_neurons += n
            continuous_populations.append(PhysicalPopulation(shape=shape, coord=coord))
        expected = np.prod(topo_graph.nodes[name]["shape"])
        if num_neurons != expected:
            raise ValueError(f"Wrong number of neurons in '{name}', expected {expected}, but got {num_neurons}")
        populations_dict[name] = continuous_populations

    # 构建PhysicalPopulation间的连接（树突和轴突）
    for u, v in tqdm(topo_graph.edges(), desc="building connections"):
        pops_u, pops_v = populations_dict[u], populations_dict[v]
        weight = pops_info[v]["weight"]
        v_start = 0
        for pop_v in pops_v:
            u_start = 0
            for pop_u in pops_u:
                if pops_info[v]["type"] == "conv":
                    step_v, step_u = pop_v.shape[0], pop_u.shape[0]
                    w = weight[v_start: v_start + step_v, u_start: u_start + step_u, :, :]
                    add_to_dendrite_conv(w, pop_u, pop_v, pops_info[v]["stride"][0], pops_info[v]["padding"][0])
                elif pops_info[v]["type"] == "fc":
                    step_v, step_u = pop_v.size, pop_u.size
                    w = weight[v_start: v_start + step_v, u_start: u_start + step_u]
                    add_to_dendrite_full(w, pop_u, pop_v)
                else:
                    raise NotImplementedError("Only support conv and fc")
                u_start += step_u
            v_start += step_v

    # 处理输出（为输出的前神经元群设置轴突）
    if output_dir is None:
        output_dir = time.strftime("%Y%m%d-%H%M%S")
    os.makedirs(output_dir, exist_ok=True)
    for pop_name, output_coords in config["output"].items():
        if pop_name not in populations_dict:
            raise ValueError(f"pop_name '{pop_name}' is invalid.")
        pre_outputs = populations_dict[pop_name]
        if len(pre_outputs) != len(output_coords):
            raise ValueError(f"'{pop_name}' need {len(pre_outputs)} virtual coordinates for output, "
                             f"but got {len(output_coords)}.")
        for i, coord in enumerate(output_coords):
            add_output_connection(
                pre_outputs[i],
                PhysicalPopulation(shape=pre_outputs[i].shape, coord=coord, pop_position="output"),
            )
        dump_output_neuron(pre_outputs, pop_name, output_dir)

    # 生成二进制数据
    for name, pop_list in tqdm(populations_dict.items(), total=len(populations_dict), desc="generating bin files"):
        if pop_list[0].pop_position != "hidden":
            continue
        dump_pop(pop_list, name, output_dir, need_description, need_show_usage)

    # 生成input_neuron.json
    dump_input_neuron(input_populations_list, output_dir)

    return output_dir


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Run the build function.")
    parser.add_argument("model_path", help="The path to the model file")
    parser.add_argument("config_file_path", help="The path to the config file")
    parser.add_argument("--core-config-module", default="user_configs",
                        help="The core config module (default: 'user_configs')")
    parser.add_argument("--output-dir", help="The output directory for the build")
    parser.add_argument("--need-description", action="store_true",
                        help="Generate description files for the compile result")
    parser.add_argument("--need-show-usage", action="store_true",
                        help="Display the usage rate of neuromorphic core memory")
    args = parser.parse_args()
    build(args.model_path, args.config_file_path, args.core_config_module, args.output_dir,
          args.need_description, args.need_show_usage)
