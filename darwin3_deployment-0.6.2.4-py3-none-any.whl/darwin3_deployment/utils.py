import math

import numpy as np


def _get_pair(value):
    return (value, value) if isinstance(value, int) else value


def calculate_conv_output_shape(input_shape, kernel_size, stride=(1, 1), padding=(1, 1), dilation=(1, 1)):
    stride = _get_pair(stride)
    padding = _get_pair(padding)
    dilation = _get_pair(dilation)
    input_channels, input_h, input_w = input_shape
    kernel_out_channels, kernel_in_channels, kernel_h, kernel_w = kernel_size
    stride_h, stride_w = stride
    padding_h, padding_w = padding
    dilation_h, dilation_w = dilation

    if input_channels != kernel_in_channels:
        raise ValueError("The number of input channels must match the number of kernel input channels")

    output_height = math.floor((input_h + 2 * padding_h - dilation_h * (kernel_h - 1) - 1) / stride_h + 1)
    output_width = math.floor((input_w + 2 * padding_w - dilation_w * (kernel_w - 1) - 1) / stride_w + 1)
    output_channels = kernel_out_channels

    return output_channels, output_height, output_width


def gen_scale_word(record):
    """Generate batch words for scale type records
    """
    contents = [np.array(getattr(record, name), dtype=np.int64) for (name, _, _) in record.__class__.bin_formats]
    word = np.bitwise_or.reduce(np.array([
        np.left_shift(np.bitwise_and(content, (1 << bitwidth) - 1), left_shift)
        for content, (name, bitwidth, left_shift) in zip(contents, record.__class__.bin_formats)
    ]))

    return word
