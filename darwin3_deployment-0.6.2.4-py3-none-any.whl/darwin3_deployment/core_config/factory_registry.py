from abc import ABC, abstractmethod

from .core_config import CoreConfig


class CoreConfigFactory(ABC):
    @classmethod
    @abstractmethod
    def create_core_config(cls, **kwargs) -> CoreConfig:
        pass


class FactoryRegistry:
    registry: dict[str, CoreConfigFactory] = {}

    @classmethod
    def register(cls, name: str, factory: CoreConfigFactory):
        cls.registry[name] = factory

    @classmethod
    def get_factory(cls, model_type: str) -> CoreConfigFactory:
        model_type = str(model_type).lower()
        if model_type not in cls.registry:
            raise ValueError(f"Unknown model type: {model_type}.")
        return cls.registry[model_type]


def register_factory(name: str):
    def decorator(cls):
        FactoryRegistry.register(name, cls)
        return cls
    return decorator
