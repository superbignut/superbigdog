import numpy as np

from .core_config import CoreConfig
from .factory_registry import CoreConfigFactory, register_factory
from ..ir.dinst import *


def quant_k(x, k):
    return np.round(x * (1 << k))


@register_factory("if")
class IFConfigFactory(CoreConfigFactory):
    @classmethod
    def create_core_config(cls, vth: int = 1) -> CoreConfig:
        """创建IF模型对应的神经拟态核配置

        IF model:
            V(t) = V(t-1) * (1 - O(t-1)) + Isyn[t] - ConstantDecay
            O^n[t] = spike_func(V^n[t-1])
        """
        core_config = CoreConfig(
            assembly_program=[
                LSIS(ls=LSIS.LS.LOAD, nph=0b0100_0100),
                UPTVT(fcs=1, fcph=0),
                GSPRS(rs=0, gspm=GSPRS.GSPM.DEFAULT, rstn=0, gsp=1, vcp=1, rsm=GSPRS.RSM.ZERO),
                LSIS(ls=LSIS.LS.STORE, nph=0b0100_0000),
                NPC(),
            ]
        )
        if isinstance(vth, str):
            core_config.set_register("CR_WORKMODE", 1 << 7)  # 使工作模式寄存器中的VK有效：树突表内阈值电压维持不变
            core_config.set_register("R1", 16384)
            core_config.assembly_program[0] = LSIS(ls=LSIS.LS.LOAD, nph=0b0110_0100)
            core_config.set_inference_state("vth", vth)
        else:
            core_config.set_register("R1", int(vth))
        return core_config


@register_factory("ifb")
class IFBConfigFactory(CoreConfigFactory):
    @classmethod
    def create_core_config(cls, vth: Union[int, str] = 1, bias: Union[int, str] = 0) -> CoreConfig:
        """创建IFB模型对应的神经拟态核配置

            IF model:
                V(t) = V(t-1) * (1 - O(t-1)) + Isyn[t] - ConstantDecay
                O^n[t] = spike_func(V^n[t-1])
            """
        core_config = CoreConfig(
            assembly_program=[
                LSIS(ls=LSIS.LS.LOAD, nph=0b0100_0110),
                ADD(rs=0, rt=5, ns=False),
                UPTVT(fcs=1, fcph=0),
                GSPRS(rs=0, gspm=GSPRS.GSPM.DEFAULT, rstn=0, gsp=1, vcp=1, rsm=GSPRS.RSM.ZERO),
                LSIS(ls=LSIS.LS.STORE, nph=0b0100_0000),
                NPC(),
            ]
        )
        if isinstance(vth, str):
            core_config.set_register("CR_WORKMODE", 1 << 7)  # 工作模式寄存器中的VK设置为有效：树突表内阈值电压维持不变
            core_config.set_register("R1", 16384)
            core_config.assembly_program[1] = LSIS(ls=LSIS.LS.LOAD, nph=0b0110_0110)
            core_config.set_inference_state("vth", vth)
        else:
            core_config.set_register("R1", int(vth))
        if isinstance(bias, str):
            core_config.set_register("CR_WORKMODE", 1 << 1)  # 工作模式寄存器中的RK设置为有效：树突表内振荡电位维持不变
            core_config.set_inference_state("res", bias)
        return core_config


@register_factory("darwin_clif")
class DarwinCLIFConfigFactory(CoreConfigFactory):
    @classmethod
    def create_core_config(cls) -> CoreConfig:
        """创建Darwin CLIF模型对应的神经拟态核配置

        Darwin CLIF Model:
            I = I*P4 + Wgt_sum
            V = V*P0 + I + P1
        """
        core_config = CoreConfig(
            assembly_program=[
                # load vt, _, i, _, wgtsum
                LSIS(ls=LSIS.LS.LOAD, nph=(LSIS.REG.Vt | LSIS.REG.I | LSIS.REG.wgtsum)),

                # cpar9 = 0, cpar4 = P4
                UPTIS(unph=0b010, fcph=0b000),

                # i = i + wgtsum
                ADD(rs=2, rt=4, ns=1),

                SFTI(rs=2, sf=SFTI.SF.LEFT, ns=1, imme=2),

                # cpar0 = P0, cpar7 = 1, cpar6 = 0, cpar1 = P1
                # vt = P0 * vt + 64 * i ( * 4)
                UPTVT(fcs=0, fcph=0b00),

                # i shift back
                SFTI(rs=2, sf=SFTI.SF.RIGHT, ns=1, imme=2),

                # generate spike
                GSPRS(rs=0, gspm=GSPRS.GSPM.DEFAULT, rstn=0, gsp=1, vcp=1, rsm=GSPRS.RSM.ZERO),

                # store vt, i
                LSIS(ls=LSIS.LS.STORE, nph=0b0101_0000),
                NPC(),
            ]
        )
        # 设置配置寄存器
        core_config.set_register("CR_QA", 8)
        dt, tau_m, tau_s = 0.1, 12, 8
        P0, P4 = quant_k(np.exp(-dt / tau_m), 8), quant_k(np.exp(-dt / tau_s), 8)
        P1 = P9 = 0
        P7 = 1 << 6
        core_config.set_register("CR_CPARA", int(P0) | (P1 << 8))
        core_config.set_register("CR_CPARB", int(P4) | (P7 << 24))
        core_config.set_register("CR_CPARC", P9 << 8)
        # 设置运行寄存器
        core_config.set_register("R1", 16384)
        # 初始化推理状态存储器
        core_config.initialize_inference_state_memory(0)
        return core_config


@register_factory("darwin_alif")
class DarwinALIFConfigFactory(CoreConfigFactory):
    @classmethod
    def create_core_config(cls) -> CoreConfig:
        """创建Darwin ALIF模型对应的神经拟态核配置

        Darwin ALIF(Adaptive threshold LIF) Model:
            I = I*P4 + Wgt_sum
            V = V*P0 + I + P1
            Vth = Vth*P2 + C1
            if spike:
                Vth = Vth + C2
        """
        core_config = CoreConfig(
            assembly_program=[
                # load vt, vth, i,  _, wgtsum
                LSIS(ls=LSIS.LS.LOAD, nph=0b0111_0100),

                # cpar9 = 1, cpar4 = P4
                UPTIS(unph=0b010, fcph=0b000),

                ADD(rs=2, rt=4, ns=False),

                SFTI(rs=2, sf=SFTI.SF.LEFT, ns=1, imme=2),

                # cpar0 = P0, cpar7 = 1, cpar6 = 0, cpar1 = P1
                UPTVT(fcs=0, fcph=0b00),

                SFTI(rs=2, sf=SFTI.SF.RIGHT, ns=1, imme=2),

                # vth = P2 * vth + C1
                MUL(rs=1, rt=3, qf=MUL.QF.REGISTER, rq=0),

                # vth += C1
                ADD(rs=1, rt=4, ns=False),

                CMP(0, 1, func=CMP.Func.GE),

                # NOTE
                JC(cmpf=1, cmpr=1, addr=12),

                # generate spike
                GSPRS(rs=0, gspm=GSPRS.GSPM.DEFAULT, rstn=0, gsp=1, vcp=0, rsm=GSPRS.RSM.ZERO),

                # Vth = Vth + C2
                ADD(rs=1, rt=5, ns=False),

                # store vt, vth, i
                LSIS(ls=LSIS.LS.STORE, nph=0b0111_0000),
                NPC(),
            ]
        )
        # 设置配置寄存器
        core_config.set_register("CR_QA", 8)
        dt, tau_m, tau_s = 0.1, 12, 8
        P0, P4 = quant_k(np.exp(-dt / tau_m), 8), quant_k(np.exp(-dt / tau_s), 8)
        P1 = P9 = 0
        P7 = 1 << 6
        core_config.set_register("CR_CPARA", int(P0) | (P1 << 8))
        core_config.set_register("CR_CPARB", int(P4) | (P7 << 24))
        core_config.set_register("CR_CPARC", P9 << 8)
        core_config.config_reg[0] |= 16384 << 16    # 神经元个数寄存器中的global_vth设置为16384
        core_config.config_reg[2] |= 1 << 2         # 工作模式寄存器中的VG设置为有效
        # 设置运行寄存器
        vth = 16384
        core_config.running_reg[3] = int(quant_k(0.999, 15))    # P2
        core_config.running_reg[4] = int(vth * 0.001)   # C1
        core_config.running_reg[5] = int(vth * 0.2)     # C2
        core_config.running_reg[8] = 15 << 8
        # 初始化推理状态存储器
        core_config.initialize_inference_state_memory(0)
        return core_config


@register_factory("darwin_default")
class DarwinDefaultConfigFactory(CoreConfigFactory):
    @classmethod
    def create_core_config(cls) -> CoreConfig:
        """创建Darwin默认的神经拟态核配置"""
        return CoreConfig(assembly_program=[NPC()])
