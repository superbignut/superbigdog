from typing import Optional

from .factories import *
from .factory_registry import FactoryRegistry


def get_model_config(model_type: str, delay: Optional[Union[int, str]] = None, **kwargs) -> CoreConfig:
    """获取指定神经元模型对应的预设神经拟态核设置

    目前支持的神经元模型：IF, IFB, darwin_clif, darwin_alif, darwin_default

    Args:
        model_type: 神经元模型名称
        delay:
            突触延时值（可以是整数或变量名）。
            值如果是字符串，则表示需要设置为突触延时值的外部变量名称，这允许在序列化时动态地将值分配给特定的寄存器；
            如果是整数，则表示将突触延时值设置为该整数值。
        **kwargs: 其他可选的关键字参数，用于配置特定的神经元模型

    Keyword Args:
        vth (int | str): 阈值电压，在IF和IFB模型中可用，默认值为1
        bias (int | str): 偏置，在IFB模型中可用，默认值为0

    Returns:
        神经拟态核设置

    Examples:
        >>> if_config = get_model_config("if", vth=1)
        >>> if_config_with_delay = get_model_config("if", delay="delay", vth=1)
        >>> ifb_config = get_model_config("ifb", vth=1, bias=0)
        >>> clif_config = get_model_config("darwin_clif")
        >>> alif_config = get_model_config("darwin_alif")
        >>> default_config = get_model_config("darwin_default")
    """
    factory = FactoryRegistry.get_factory(model_type)
    core_config = factory.create_core_config(**kwargs)
    if delay is not None:
        core_config.add_synaptic_delay(delay)
    return core_config
