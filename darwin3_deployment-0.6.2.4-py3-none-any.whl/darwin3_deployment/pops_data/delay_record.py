class DelayRecord:
    _instance = None

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(DelayRecord, cls).__new__(cls, *args, **kwargs)
        return cls._instance

    def __init__(self):
        # 使用字典来存储每一层的数据
        if not hasattr(self, 'delay_record'):
            self.delay_record = {}

    def set_delay(self, coord, data: list[int]):
        """
        设置指定层的数据。
        :param coord: 核心位置
        :param data: 要设置的数据，格式为[delay_reg1, delay_val_1, delay_reg2, delay_val_2]
        """
        if coord in self.delay_record:
            raise ValueError(f"coord {coord} has been reused.")
        # 更新delay数据
        coord_str = str(coord)
        self.delay_record[coord_str] = data

