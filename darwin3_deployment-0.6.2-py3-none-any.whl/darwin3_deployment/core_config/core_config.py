from collections.abc import Sequence
import re
from typing import Any, Optional

import numpy as np

from ..ir.dinst import *


def parse_var(input_str) -> tuple[str, Optional[int]]:
    pattern = r"(\w+)(?:\[(\d+)\])?"
    match = re.fullmatch(pattern, input_str)
    if match:
        var_name = match.group(1)
        if match.group(2) is not None:
            return var_name, int(match.group(2))
        else:
            return var_name, None
    else:
        raise ValueError(f"Invalid name: {input_str}")


class CoreConfig:
    """核心配置，设置和管理神经拟态核配置寄存器、运行寄存器和指令存储器的值

    Args:
        config_reg: 一个序列，包含所有配置寄存器的值，长度应为32
        running_reg: 一个序列，包含所有运行寄存器的值，长度应为16
        assembly_program: 一个序列，表示一个汇编程序，序列的每个元素表示一条指令，序列长度不超过128
        register_settings:
            一个字典，用于将寄存器名称与一个外部变量名称或一个整数值进行映射。
            字典的键表示寄存器的名称，
            值如果是字符串，则表示应绑定到这些寄存器的外部变量名称，这允许在序列化时动态地将值分配给特定的寄存器;
            如果是整数，则表示将指定寄存器设置为该整数值。默认为 `None`。
        inference_state_settings:
            一个字典，用于将推理状态存储器中的字段名称与一个外部变量名称或一个整数值进行映射。
            字典的键表示推理状态存储器中的字段名称，
            值如果是字符串，则表示应绑定到这些字段的外部变量名称，这允许在序列化时动态地将值分配给特定的存储器字段；
            如果是整数，则表示将整个推理状态存储器的指定字段设置为该整数值。默认为 `None`。
        inference_parameter_settings:
            一个字典，用于将推理参数存储器中的字段名称与一个外部变量名称或一个整数值进行映射。
            字典的键表示推理参数存储器中的字段名称，
            值如果是字符串，则表示应绑定到这些字段的外部变量名称，这允许在序列化时动态地将值分配给特定的存储器字段；
            如果是整数，则将表示整个推理参数存储器的指定字段设置为该整数值。默认为 `None`。
        delay:
            突触延时值（可以是整数或变量名）。
            值如果是字符串，则表示需要设置为突触延时值的外部变量名称，这允许在序列化时动态地将值分配给特定的寄存器；
            如果是整数，则表示将突触延时值设置为该整数值。
    """
    _CONF_REG_MAP = {
        "CR_NEURONNUM": 0, "CR_DENDRITENUM": 1, "CR_WORKMODE": 2, "CR_RPD": 3, "CR_STATE": 4,
        "CR_PC": 5, "SR_ERROR": 6, "CR_INTMASK": 7, "CR_QA": 8, "CR_RANDMOD": 9, "CR_RANDSEED": 10,
        "CR_LPARXY": 11, "CR_LPARR": 12, "CR_WPARA": 13, "CR_WPARB": 14, "CR_WPARC": 15, "CR_WPARD": 16,
        "CR_CPARA": 17, "CR_CPARB": 18, "CR_CPARC": 19, "SR_PKGCNT": 20, "CR_EN": 21, "CR_VTDEC": 22,
        "SR_SPKINCNT": 23, "SR_SPKOUTCNT": 24, "SR_DS0": 25, "SR_DS1": 26, "CR_DRH": 27, "CR_CGEN": 28,
        "CR_LINKSIZE": 29, "CR_LI": 30, "CR_TN": 31,
    }
    _RUNNING_REG_MAP = {f"R{i}": i for i in range(16)}
    _INFERENCE_STATE_MAP = {"I": (16, 32), "VTH": (16, 16), "RES": (16, 0), "RPD": (8, 8), "PAR0": (8, 0)}
    _INFERENCE_PARAMETER_MAP = {f"PAR{i}": (8, i * 8) for i in range(6)}

    def __init__(
        self,
        config_reg: Sequence[int] = None,
        running_reg: Sequence[int] = None,
        assembly_program: Sequence[DInst] = None,
        register_settings: dict[str, str] = None,
        inference_state_settings: dict[str, Union[int, str]] = None,
        inference_parameter_settings: dict[str, Union[int, str]] = None,
        delay: Union[int, str] = None,
    ):
        self.config_reg = [0] * 32
        self.config_reg[8] = 0x80           # 精度寄存器 截取方式默认为对称四舍五入
        self.config_reg[9] = 0x20000003     # 随机模式寄存器
        self.config_reg[10] = 0xffffffff    # 随机种子寄存器
        self.config_reg[29] = 0xffff        # 连接区间大小

        self.running_reg = [0] * 16
        self._delay_reg: Optional[tuple[int, int]] = None   # 存放delay值的运行寄存器，用于突触延时对齐
        self._delay: Optional[Union[int, str]] = None

        self.instruction_memory: list[int] = []
        self.assembly_program: list[DInst] = []

        self._var_to_reg_mapping: dict[tuple[str, Optional[int]], tuple[str, int]] = {}
        self.bound_variable_set: set[str] = set()

        self.inference_states = {}
        self.inference_parameters = {}
        self.initial_inference_state_memory: Optional[int] = None
        self.initial_inference_parameter_memory: Optional[int] = None

        if config_reg is not None:
            self.set_config_registers(config_reg)
        if running_reg is not None:
            self.set_running_registers(running_reg)
        if assembly_program is not None:
            self.set_assembly_program(assembly_program)
        if register_settings is not None:
            self.set_registers_by_name(register_settings)
        if inference_state_settings is not None:
            self.set_inference_states(inference_state_settings)
        if inference_parameter_settings is not None:
            self.set_inference_parameters(inference_parameter_settings)
        if delay is not None:
            self.add_synaptic_delay(delay)

    def get_core_config_value(self, pop_data: Optional[dict[str, Any]] = None) \
            -> tuple[list[int], list[int], list[int], Optional[Union[np.ndarray, int]], Optional[Union[np.ndarray, int]]]:
        """获取配置寄存器，运行寄存器、指令存储器、推理状态存储器和推理参数存储器的设定值"""
        config_reg = self.config_reg.copy()
        running_reg = self.running_reg.copy()
        inst_mem = self.instruction_memory.copy()
        inf_state = self.initial_inference_state_memory
        inf_param = self.initial_inference_parameter_memory
        if pop_data:
            self._apply_register_bindings(pop_data, config_reg, running_reg)
            inf_state = self.get_inference_state_value(pop_data)
            inf_param = self.get_inference_parameter_value(pop_data)
        return config_reg, running_reg, inst_mem, inf_state, inf_param

    def set_register(self, reg_name: str, value: Union[int, str]):
        """设置指定寄存器的值

        Args:
            reg_name: 寄存器名称
            value:
                寄存器值（可以是数值或变量名）。
                值如果是字符串，则表示应绑定到这些寄存器的外部变量名称，这允许在序列化时动态地将值分配给特定的寄存器;
                如果是整数，则表示将指定寄存器设置为该整数值。
        """
        reg_name_ = str(reg_name).upper()
        if self._delay_reg and reg_name in {f"R{self._delay_reg[0]}", f"R{self._delay_reg[1]}"}:
            print(f"Warning: {reg_name} was used for the synaptic delay, but is now being overwritten.")
        if not isinstance(value, str):
            value = int(value)
            if reg_name_ in self._CONF_REG_MAP:
                self.config_reg[self._CONF_REG_MAP[reg_name_]] = value
            elif reg_name_ in self._RUNNING_REG_MAP:
                self.running_reg[self._RUNNING_REG_MAP[reg_name_]] = value
            else:
                raise ValueError(f"Invalid register name '{reg_name}'")
        else:
            var_name, index = parse_var(str(value))
            self.bound_variable_set.add(var_name)
            if reg_name_ in self._CONF_REG_MAP:
                self._var_to_reg_mapping[(var_name, index)] = "config", self._CONF_REG_MAP[reg_name_]
            elif reg_name_ in self._RUNNING_REG_MAP:
                self._var_to_reg_mapping[(var_name, index)] = "running", self._RUNNING_REG_MAP[reg_name_]
            else:
                raise ValueError(f"Invalid register name '{reg_name}'")

    def set_config_registers(self, config_reg: Sequence[int]):
        """设置所有配置寄存器的值

        Args:
            config_reg: 一个序列，包含所有配置寄存器的值，长度应为32
        """
        config_reg = list(config_reg)
        if len(config_reg) != 32:
            raise ValueError(f"Number of config registers must be 32, but got {len(config_reg)}")
        self.config_reg = config_reg

    def set_running_registers(self, running_reg: Sequence[int]):
        """设置所有运行寄存器的值

        Args:
            running_reg: 一个序列，包含所有运行寄存器的值，长度应为16
        """
        running_reg = list(running_reg)
        if len(running_reg) != 16:
            raise ValueError(f"Number of running registers must be 16, but got {len(running_reg)}")
        self.running_reg = running_reg

    def set_assembly_program(self, assembly_program: Sequence[DInst]):
        """设置汇编程序

        Args:
            assembly_program: 一个序列，表示一个汇编程序，序列的每个元素表示一条指令，序列长度不超过128
        """
        if len(assembly_program) > 128:
            raise ValueError(f"The maximum number of instructions is 128, but got {len(assembly_program)}.")
        for instruction in assembly_program:
            if not isinstance(instruction, DInst):
                raise ValueError("Instruction must be an instance of DInst")
        self.assembly_program = assembly_program
        if self._delay is not None:
            self.add_synaptic_delay(self._delay)
        self.instruction_memory = [inst.serialize() for inst in self.assembly_program]

    def set_instruction_memory(self, instruction_memory: Sequence[int]):
        """设置指令存储器的值"""
        if not all(isinstance(item, int) for item in instruction_memory):
            raise ValueError("All items in instruction_memory must be integers")
        self.instruction_memory = list(instruction_memory)

    def has_bound_variable(self) -> bool:
        """核心设置中是否存在绑定变量"""
        return len(self.bound_variable_set) > 0

    def set_registers_by_name(self, register_settings: dict[str, Union[int, str]]):
        """设置多个指定寄存器的值

        Args:
            register_settings:
                一个字典，用于将寄存器名称与一个外部变量名称或一个整数值进行映射。
                字典的键表示寄存器的名称，
                值如果是字符串，则表示应绑定到这些寄存器的外部变量名称，这允许在序列化时动态地将值分配给特定的寄存器；
                如果是整数，则表示将指定寄存器设置为该整数值。
        """
        for reg_name, var_name in register_settings.items():
            self.set_register(reg_name, var_name)

    def _apply_register_bindings(self, pop_data: dict[str, Any], config_reg: list[int], running_reg: list[int]):
        for (var_name, index), (reg_type, reg_index) in self._var_to_reg_mapping.items():
            if var_name in pop_data:
                value = int(pop_data[var_name] if index is None else pop_data[var_name][index])
                if reg_type == "config":
                    config_reg[reg_index] += value
                elif reg_type == "running":
                    if self._delay_reg and reg_index in self._delay_reg:
                        self._validate_delay_value(value)
                    running_reg[reg_index] += value

    def set_inference_state(self, state_name: str, value: Union[int, str]):
        """设置一个推理状态

        Args:
            state_name: 推理状态存储器中的字段名称
            value:
                推理状态值（可以是整数或变量名）。
                值如果是字符串，则表示应绑定到这些字段的外部变量名称，这允许在序列化时动态地将值分配给特定的存储器字段；
                如果是整数，则表示将整个推理状态存储器的指定字段设置为该整数值。
        """
        state_name_ = str(state_name).upper()
        if state_name_ not in self._INFERENCE_STATE_MAP:
            raise ValueError(f"Inference state name '{state_name}' is invalid. "
                             "Please use one of the following: 'i', 'vth', 'res', 'rpd' or 'par0'.")
        if isinstance(value, str):
            self.inference_states[state_name_] = value
            self.bound_variable_set.add(value)
        else:
            value = int(value)
            length, shift = self._INFERENCE_STATE_MAP[state_name_]
            mask = (1 << length) - 1
            if self.initial_inference_state_memory is None:
                self.initial_inference_state_memory = 0
            self.initial_inference_state_memory |= (value & mask) << shift

    def set_inference_states(self, inference_state_settings: dict[str, Union[int, str]]):
        """设置多个推理状态

        Args:
            inference_state_settings:
                一个字典，用于将推理状态存储器中的字段名称与一个外部变量名称或一个整数值进行映射。
                字典的键表示推理状态存储器中的字段名称，
                值如果是字符串，则表示应绑定到这些字段的外部变量名称，这允许在序列化时动态地将值分配给特定的存储器字段；
                如果是整数，则表示将整个推理状态存储器的指定字段设置为该整数值。
        """
        for state, value in inference_state_settings.items():
            self.set_inference_state(state, value)

    def set_inference_parameter(self, param_name: str, value: Union[int, str]):
        """设置一个推理参数

        Args:
            param_name: 推理参数存储器中的字段名称
            value:
                推理参数值（可以是整数或变量名）。
                值如果是字符串，则表示应绑定到这些字段的外部变量名称，这允许在序列化时动态地将值分配给特定的存储器字段；
                如果是整数，则表示将整个推理参数存储器的指定字段设置为该整数值。
        """
        param_name_ = str(param_name).upper()
        if param_name_ not in self._INFERENCE_PARAMETER_MAP:
            raise ValueError(f"Inference parameter name '{param_name}' is invalid. "
                             "Please use 'par0' to 'par5'.")
        if isinstance(value, str):
            self.inference_parameters[param_name_] = value
            self.bound_variable_set.add(value)
        else:
            value = int(value)
            length, shift = self._INFERENCE_PARAMETER_MAP[param_name_]
            mask = (1 << length) - 1
            if self.initial_inference_parameter_memory is None:
                self.initial_inference_parameter_memory = 0
            self.initial_inference_parameter_memory |= (value & mask) << shift

    def set_inference_parameters(self, inference_parameter_settings: dict[str, Union[int, str]]):
        """设置多个推理参数

        Args:
            inference_parameter_settings:
                一个字典，用于将推理参数存储器中的字段名称与一个外部变量名称或一个整数值进行映射。
                字典的键表示推理参数存储器中的字段名称，
                值如果是字符串，则表示应绑定到这些字段的外部变量名称，这允许在序列化时动态地将值分配给特定的存储器字段；
                如果是整数，则表示将整个推理参数存储器的指定字段设置为该整数值。
        """
        for param, value in inference_parameter_settings.items():
            self.set_inference_parameter(param, value)

    def get_inference_state_value(self, pop_data: dict[str, Any]) -> Optional[np.ndarray]:
        if not self.inference_states:
            return self.initial_inference_state_memory
        inference_state = 0
        for state, var_name in self.inference_states.items():
            if var_name not in pop_data:
                raise ValueError(f"Missing variable '{var_name}' set as inference state {state}")
            value = np.asarray(pop_data[var_name], dtype=np.int64)
            length, shift = self._INFERENCE_STATE_MAP[state]
            mask = (1 << length) - 1
            inference_state += (value & mask) << shift
        if self.initial_inference_state_memory is not None:
            inference_state += self.initial_inference_state_memory
        return inference_state.reshape(-1)

    def get_inference_parameter_value(self, pop_data: dict[str, Any]) -> Optional[np.ndarray]:
        if not self.inference_parameters:
            return self.initial_inference_parameter_memory
        inference_parameter = 0
        for state, var_name in self.inference_parameters.items():
            if var_name not in pop_data:
                raise ValueError(f"Missing variable '{var_name}' set as inference parameter {state}")
            value = np.asarray(pop_data[var_name], dtype=np.int64)
            length, shift = self._INFERENCE_PARAMETER_MAP[state]
            mask = (1 << length) - 1
            inference_parameter += (value & mask) << shift
        if self.initial_inference_parameter_memory is not None:
            inference_parameter += self.initial_inference_parameter_memory
        return inference_parameter.reshape(-1)

    def initialize_inference_state_memory(self, value: int = 0):
        """初始化推理状态存储器

        Args:
            value: 初始值
        """
        self.initial_inference_state_memory = int(value)

    def initialize_inference_parameter_memory(self, value: int = 0):
        """初始化推理参数存储器

        Args:
            value: 初始值
        """
        self.initial_inference_parameter_memory = int(value)

    def add_synaptic_delay(self, delay: Union[int, str]):
        """添加突触延时

        Args:
            delay:
                突触延时值（可以是整数或变量名）。
                值如果是字符串，则表示需要设置为突触延时值的外部变量名称，这允许在序列化时动态地将值分配给特定的寄存器；
                如果是整数，则表示将突触延时值设置为该整数值。

        Notes:
            该方法会遍历已有的汇编代码，寻找两个未被使用的寄存器放置 `delay`，如果没有，则抛出异常
        """
        if not isinstance(delay, str):
            delay = int(delay)
            self._validate_delay_value(delay)
        unused_reg_set = self._find_unused_running_registers()
        if len(unused_reg_set) < 2:
            raise ValueError("Not enough available registers to store the synaptic delay. "
                             "Ensure that there are at least two unused registers.")
        high_reg = unused_reg_set.pop()
        low_reg = unused_reg_set.pop()
        print(f"[INFO] R{high_reg} and R{low_reg} are used for the synaptic delay.")
        self.set_register(f"R{low_reg}", delay)
        self._delay = delay
        if self._delay_reg == (high_reg, low_reg):  # 已插入汇编，且无需修改
            return
        insert_program = [
            CMP(low_reg, low_reg, 3),
            JC(1, 0, 4),
            ADDI(low_reg, -1),
            NPC(),
            CMP(high_reg, high_reg, 3),
            JC(1, 0, 10),
            ADDI(high_reg, -1),
            ADDI(low_reg, 1),
            SFTI(low_reg, 0, 0, 15),
            NPC(),
        ]
        if self._delay_reg is None:     # 未插入汇编
            remaining_space = 128 - len(insert_program)
            if len(self.assembly_program) > remaining_space:
                raise ValueError(f"Assembly program length exceeds limit when using synaptic delay. "
                                 f"Max allowed: {remaining_space}, current: {len(self.assembly_program)}.")
            self.assembly_program = insert_program + self._adjust_jump_targets(self.assembly_program, len(insert_program))
        else:   # 已插入汇编，需要更新存放delay的寄存器
            self.assembly_program[:len(insert_program)] = insert_program
        self.instruction_memory = [inst.serialize() for inst in self.assembly_program]
        self._delay_reg = (high_reg, low_reg)

    @property
    def delay_reg(self) -> Optional[tuple[int, int]]:
        return self._delay_reg

    @staticmethod
    def _validate_delay_value(delay: int):
        if delay < 0 or delay >= 1 << 18:
            raise ValueError(f"'delay' must be a non-negative integer less than {1 << 18}, but got {delay}.")

    def _find_unused_running_registers(self) -> set[int]:
        used_registers = set()
        for inst in self.assembly_program:
            for op in inst.operands:
                used_registers.add(op)
        return set(range(16)) - used_registers

    @staticmethod
    def _adjust_jump_targets(assembly_program: list[DInst], offset: int):
        offset = int(offset)
        for inst in assembly_program:
            if isinstance(inst, JC):
                inst.addr += offset
        return assembly_program
