from collections.abc import Sequence
from typing import Optional, Union
from tabulate import tabulate
from enum import Enum

import numpy as np


class WeightArray:
    def __init__(self, array):
        self.array = array

    def __eq__(self, value):
        eq = self.array == value
        if isinstance(eq, bool):
            return eq
        else:
            return eq.all()

    def __len__(self):
        return np.size(self.array)

    def __repr__(self):
        return repr(self.array)


class NeuronArray:
    def __init__(self, array):
        self.array = array

    def __eq__(self, value):

        if len(self.array) == len(value):
            offset = self.array[0] - value[0]
            diff = np.array(self.array) - np.array(value) - offset
            eq = diff == 0
        else:
            eq = self.array == value
        if isinstance(eq, bool):
            return eq
        else:
            return eq.all()

    def __getitem__(self, key):
        return self.array[key]

    def __len__(self):
        return len(self.array)

    def __repr__(self):
        return repr(self.array)


class NetPopulation:
    _subclass = dict()

    def __new__(
        cls,
        label,
        neuron_label_set=set(),
        parameters=dict(),
        pop_type=None,
        pop_position='hidden',
        **kwargs,
    ):
        if pop_type in cls._subclass:
            return cls._subclass[pop_type](
                label,
                neuron_label_set,
                parameters,
                pop_type,
                pop_position,
                **kwargs,
            )
        else:
            raise ValueError(f"{pop_type} is not one of the supported population type")

    @classmethod
    def register(cls, name, subclass):
        name = name.lower()
        cls._subclass[name] = subclass


class WeightQA(Enum):
    QA_16 = 16
    QA_8 = 8
    QA_6 = 6
    QA_4 = 4
    QA_2 = 2


class PhysicalPopulation:
    """Representing the physical population, one of each can only mapped to a single node"""

    _used_coords = set()

    def __init__(
        self,
        shape: Sequence[int],
        coord: Sequence[int],
        pop_position: str = "hidden",
        weight_qa: WeightQA = WeightQA.QA_8,
        **kwargs,
    ):
        shape_ = np.asarray(shape, dtype=int).reshape(-1)
        if not (shape_.size > 0 and np.all(shape_ > 0)):
            raise ValueError("Shape of PhysicalPopulation must be a non-empty sequence of positive integers.")
        shape_ = tuple(int(size) for size in shape_)

        coord_ = tuple(int(c) for c in coord)
        if len(coord_) != 2:
            raise ValueError(f"'coord' must be a 2D coordinate in the format (x, y), but got {coord_}.")
        if coord_ == (0, 0):
            raise ValueError("The core at (0, 0) is a RISC-V core, not a neuromorphic core.")
        if pop_position == "hidden" and (coord_[0] < 0 or coord_[0] > 23 or coord_[1] < 0 or coord_[1] > 23):
            raise ValueError(f"Coordinate {coord_} is invalid, valid range is 0 to 23.")
        if coord_ in PhysicalPopulation._used_coords:
            raise ValueError(f"Coordinate {coord_} is already in use by another PhysicalPopulation instance.")
        PhysicalPopulation._used_coords.add(coord_)

        self.shape: tuple[int, ...] = shape_
        self.coord: tuple[int, int] = coord_
        self.pop_position = str(pop_position)

        self._neurons: np.ndarray = np.arange(np.prod(self.shape), dtype=int)  # 当前PhysicalPopulation的所有神经元
        self._dendrites = []  # [neuron_id, type, length, share, weight] 神经元id表地址，类型，突触后神经元个数，共享，权重表地址
        self._neuron_ids = []  # 神经元序号表
        self._weights = []  # 权重表
        self._axons: dict[int, list[int]] = {i: [] for i in
                                             range(self.size)}  # 突触前神经元id: [突触后神经元id, 轴突id（在axon_out中的索引）, 轴突id, ...]
        self._axon_out: list[list[Union[PhysicalPopulation, int]]] = []  # [pop, den_id] 突触后神经元群，树突id
        self._weight_qa = weight_qa

        if coord[0] % 4 < 2:
            self.core_type = "big"
            self._DENDRITE_MEMORY_SIZE = 1 << 16
        else:
            self.core_type = "little"
            self._DENDRITE_MEMORY_SIZE = 1 << 13
        self._AXON_MEMORY_SIZE = 1 << 14
        self.inf_state_start_addr = self._DENDRITE_MEMORY_SIZE  # 推理状态存储区起始地址
        self.inf_param_start_addr = self._DENDRITE_MEMORY_SIZE - 4096  # 推理参数存储区起始地址

    def __repr__(self):
        pm_name = self.__class__.__qualname__
        return f"{pm_name}(size={self.size}, shape={self.shape}, coord={self.coord}, pop_position='{self.pop_position}')"

    @property
    def size(self) -> int:
        """神经元群的大小（神经元的数量）"""
        return self._neurons.size

    @property
    def dendrite_memory_size(self) -> int:
        """神经元群所在神经拟态核树突存储器的大小"""
        return self._DENDRITE_MEMORY_SIZE

    @property
    def axon_memory_size(self) -> int:
        """神经元群所在神经拟态核轴突存储器的大小"""
        return self._AXON_MEMORY_SIZE

    @property
    def num_dendrites(self) -> int:
        """神经元群的树突数量（树突元数据数量）"""
        return len(self._dendrites)

    @property
    def weight_qa(self) -> int:
        return self._weight_qa.value

    def weight_qa_serialize(self):
        wgt_qa = 0b000
        weight_len = self.weight_qa
        if weight_len == 16:
            wgt_qa = 0b100
        elif weight_len == 8:
            wgt_qa = 0b000
        elif weight_len == 6:
            wgt_qa = 0b001
        elif weight_len == 4:
            wgt_qa = 0b010
        elif weight_len == 2:
            wgt_qa = 0b011
        return wgt_qa << 24

    def get_dendrite_id_by_axon_id(self, axon_id: int):
        if axon_id >= self.size:
            raise ValueError("axon_id out of range")
        axon_out_ids = self._axons[axon_id][1:]
        dendrite_ids = []
        for axon_out_id in axon_out_ids:
            if not self._axon_out[axon_out_id][0].check_coord_in_chip():
                dendrite_ids.append(self._axon_out[axon_out_id][1])
        return dendrite_ids

    def check_coord_in_chip(self):
        x = self.coord[0]
        y = self.coord[1]
        if x < 0 or x >= 24 or y < 0 or y >= 24:
            return False
        return True

    def add_dendrite(self, neuron_id: list[int], weight: Union[list[int], int], share: bool = False,
                     type: int = 0, length: Optional[int] = None) -> int:
        """添加树突数据

        Args:
            neuron_id: 突触后神经元序号
            weight: 权重
            share: 是否共享权重
            type: 连接类型
            length: 突触后神经元个数

        Returns:
            树突编号

        Notes:
            `share` 为 `True` 时，`weight` 应为一个整数；`share` 为 `False` 时，`weight` 应为一个整数列表
        """
        den_id = len(self._dendrites)
        if length is None:
            length = len(neuron_id)
        if neuron_id in self._neuron_ids:  # 神经元序号表
            _neuron_id = self._neuron_ids.index(neuron_id)
            neuron_id = _neuron_id
        else:
            self._neuron_ids.append(neuron_id)
            neuron_id = len(self._neuron_ids) - 1
        if not share:  # 权重不共享
            if weight in self._weights:  # 权重表
                waddr = self._weights.index(weight)
            else:
                self._weights.append(weight)
                waddr = len(self._weights) - 1
            dendrite = [neuron_id, type, length, share, waddr]
        else:  # 权重共享
            wgt = int(weight)
            dendrite = [neuron_id, type, length, share, wgt]
        if dendrite in self._dendrites:  # 树突元数据
            den_id = self._dendrites.index(dendrite)
        else:
            self._dendrites.append(dendrite)
        return den_id

    def dendrite_description(self):
        dendrite = []
        # [neuron_id, type, length, share, weight] 神经元id表地址，类型，突触后神经元个数，共享，权重表地址
        den_data_header = ["树突id", "神经元序号表id", "树突类型", "突触后神经元个数", "是否共享权重", "权重表id"]

        den_data = tabulate(self._dendrites, headers=den_data_header, tablefmt="pipe", showindex="always")

        neu_ids_header = ["神经元序号表id", "突触后神经元序号"]
        neu_ids = []
        for ids in self._neuron_ids:
            neu_ids.append([ids])
        neu_ids_data = tabulate(neu_ids, headers=neu_ids_header, tablefmt="pipe", showindex="always")

        weights_header = ["权重表id", "权重"]
        weights = []
        for wgt in self._weights:
            weights.append([wgt])
        weights_data = tabulate(weights, headers=weights_header, tablefmt="pipe", showindex="always")

        return den_data, neu_ids_data, weights_data

    def __check_value_overflow__(self, val: int):
        wgt_len = self.weight_qa
        min_val = -(1 << (wgt_len - 1))
        max_val = (1 << (wgt_len - 1)) - 1
        if val > max_val or val < min_val:
            print(f"[WARN] Core{self.coord} weight overflow.")
            return True
        return False

    def dendrite_serialize(self):
        dendrite_bin = {}
        addr = len(self._dendrites)
        id_addrs = []
        wgt_addrs = []
        weight_qa = self._weight_qa

        for ids in self._neuron_ids:  # 神经元编号表
            index = 0
            id_addrs.append(addr)
            num_addr = (len(ids) + 3) // 4
            for i in range(num_addr):
                dendrite_bin[addr + i] = 0
                for j in range(4):
                    if index >= len(ids):
                        break
                    dendrite_bin[addr + i] += ids[index] << 12 * (3 - j)  # 神经元编号表 神经元编号宽度=12 一行4个神经元
                    index += 1
            addr += num_addr
        for wgt in self._weights:  # 权重表
            weight_num = 48 // weight_qa.value
            index = 0
            wgt_addrs.append(addr)
            num_addr = (len(wgt) + weight_num - 1) // weight_num
            wgt = np.array(wgt, dtype=np.int64)
            for i in range(num_addr):
                dendrite_bin[addr + i] = 0
                for j in range(weight_num):
                    if index >= len(wgt):
                        break
                    self.__check_value_overflow__(wgt[index])
                    dendrite_bin[addr + i] += (wgt[index] & 0xffff) << weight_qa.value * (
                                weight_num - 1 - j)  # 权重表 权重位宽=weight_qa 一行48 / weight_qa个权重
                    index += 1
            addr += num_addr
        for den_id, (neuron_id, type, length, share, weight) in enumerate(self._dendrites):  # 树突元数据
            wgt = weight if share else wgt_addrs[weight]
            dendrite_bin[den_id] = ((id_addrs[neuron_id] & 0xfff) << 32) | ((type & 0x7) << 29) | \
                                   (((length - 1) & 0xfff) << 17) | (share << 16) | (wgt & 0xffff)
        return dendrite_bin

    def add_axon(self, neuron_id: int, neu_index: int, pop: "PhysicalPopulation", den_id: int):
        """添加轴突数据

        Args:
            neuron_id: 突触前神经元序号
            neu_index: 突触后神经元序号/偏移
            pop: 突触后神经元群
            den_id: 树突序号
        """
        axon_id = len(self._axon_out)
        if len(self._axons[neuron_id]) == 0:
            self._axons[neuron_id].append(neu_index)
        elif neu_index != -1:
            if self._axons[neuron_id][0] == -1:
                self._axons[neuron_id][0] = neu_index
            assert self._axons[neuron_id][0] == neu_index, "neu_index is mismatched!"  # 不能添加不同的神经元编号偏移
        if [pop, den_id] in self._axon_out:
            axon_id = self._axon_out.index([pop, den_id])
        else:
            self._axon_out.append([pop, den_id])
        self._axons[neuron_id].append(axon_id)

    def axon_description(self):
        axon = []
        for i in range(len(self._axons)):
            post_neu_id = self._axons[i][0]
            axon_out_ids = self._axons[i][1:]
            axon.append([i, axon_out_ids, post_neu_id])
        axon_header_name = ["轴突编号", "目标条目表序号", "神经元索引"]
        axon_data = tabulate(axon, headers=axon_header_name, tablefmt="pipe")

        axon_out = []
        for i in range(len(self._axon_out)):
            pop = self._axon_out[i][0]
            den_id = self._axon_out[i][1]
            axon_out.append([i, pop.coord, den_id])
        axon_out_header_name = ["目标条目表编号", "目标核心坐标", "目标树突序号"]
        axon_out_data = tabulate(axon_out, headers=axon_out_header_name, tablefmt="pipe")
        return axon_data, axon_out_data

    def axon_serialize(self):
        axon_bin = {}
        addr = self.size
        axons = {}
        axons_out = []
        axon_addrs = []
        for neuron_id, axon_ids in self._axons.items():
            if not axon_ids:
                continue
            if axon_ids[0] < 0:  # 将设置为-1的neu_idx改为0
                axon_ids[0] = 0
            if axon_ids[1:] in axons_out:
                axon_id = axons_out.index(axon_ids[1:])
            else:
                axon_id = len(axons_out)
                axons_out.append(axon_ids[1:])
                axon_addrs.append(addr)
                num_addr = len(axon_ids[1:])
                for i in range(num_addr):  # 目标条目表
                    pop, den_id = self._axon_out[axon_ids[i + 1]]
                    axon_bin[addr + i] = (
                            (pop.coord[0] < self.coord[0]) << 24
                            | (abs(pop.coord[0] - self.coord[0]) & 0xf) << 20
                            | (pop.coord[1] < self.coord[1]) << 19
                            | (abs(pop.coord[1] - self.coord[1]) & 0xf) << 15
                            | (den_id & 0x7fff)
                    )
                addr += num_addr
                axon_bin[addr - 1] += 1 << 25
            axons[neuron_id] = [axon_ids[0], axon_id]
        for neuron_id, axon_ids in axons.items():  # 轴突元数据
            axon_bin[neuron_id] = (axon_addrs[axon_ids[1]] << 12) + axon_ids[0]
        return axon_bin

    def remove_empty_axon(self):
        """
        删除无轴突的神经元

        """
        # axon = {k: v for k, v in self._axons.items() if len(v) > 0}
        empty_axon = [k for k, v in self._axons.items() if len(v) == 0]
        if len(empty_axon) == 0:
            return
        # sorted_axon = {}
        # index_map = {}
        # index = 0
        # for k in axon:
        #     sorted_axon[index] = axon[k]
        #     index_map[k] = index
        #     index += 1
        print(f"[ERROR] Core {self.coord} contains empty axon {empty_axon}. The problem can be resolved by the following steps:")
        print("1. Create a weight vector with a shape of [empty_axon_size], and initialize all the weights to 0.")
        print("2. Add one-to-one connections for the current PhysicalPopulation and a certain nearby PhysicalPopulation (which can be newly created or already existing).")
        print(f"add_one_to_one_connection([0]*{len(empty_axon)}, cur_pop, nearby_pop, {empty_axon}, [0]*{len(empty_axon)})")
        # for i in range(len(self._neuron_ids)):
        #     for j in range(len(self._neuron_ids[i])):
        #         if self._neuron_ids[i][j] in empty_axon:
        #             self._weights[i][j] = 0
        #
        # for i in range(len(self._neuron_ids)):
        #     for j in range(len(self._neuron_ids[i])):
        #         if self._neuron_ids[i][j] in index_map:
        #             self._neuron_ids[i][j] = index_map[self._neuron_ids[i][j]]
        # self._axons = sorted_axon
        # self._neurons = np.arange(len(axon), dtype=int)

    def validate_neu_index(self, dendrites: dict[int, list[int]]) -> bool:
        for neu_id, dendrite in dendrites.items():
            neu_index = dendrite[0]
            if len(self._axons[neu_id]) > 0 and self._axons[neu_id][0] != neu_index:
                return False
        return True


class ContinuousPopulation(NetPopulation):
    """Representing a net population with continuous neuron ids
    """

    def __init__(
        self,
        label,
        neuron_label_set=set(),
        parameters=dict(),
        pop_type='continuous',
        pop_position='hidden',
        **kwargs,
    ):
        super().__init__(
            label=label,
            neuron_label_set=neuron_label_set,
            parameters=parameters,
            pop_type=pop_type,
            pop_position=pop_position,
            **kwargs,
        )
        self._neurons: np.ndarray = np.sort(list(neuron_label_set))
        if len(self._neurons) > 0:
            self._bias = self._neurons[0]
            self._neurons_relative = np.array(list(neuron_label_set)) - self._bias
            self._num = len(neuron_label_set)
        else:
            self._bias = 0
            self._neurons_relative = self._neurons
            self._num = 0
        for i in range(self._num):
            self.axons[i] = []


NetPopulation.register('continuous', ContinuousPopulation)
