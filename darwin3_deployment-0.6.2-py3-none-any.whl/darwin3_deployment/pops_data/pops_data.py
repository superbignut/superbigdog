class PopsDataConfig:
    _instance = None

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(PopsDataConfig, cls).__new__(cls, *args, **kwargs)
        return cls._instance

    def __init__(self):
        # 使用字典来存储每一层的数据
        if not hasattr(self, 'pops_data'):
            self.pops_data = {}

    def set_pops_data(self, pops_data):
        self.pops_data = pops_data

    def set_pop_data(self, pop_name, **data):
        """
        设置指定层的数据。
        :param pop_name: 层的名称 (str)
        :param data: 要设置的数据，可以是任意键值对，如权重、偏置等
        """
        if pop_name not in self.pops_data:
            self.pops_data[pop_name] = {}

        # 更新层的数据
        self.pops_data[pop_name].update(data)

    def get_pop_data(self, pop_name, data_key=None):
        """
        获取指定层的数据。
        :param pop_name: 层的名称 (str)
        :param data_key: 要获取的数据的键 (str)，如果为 None，则返回整个层的数据
        :return: 指定的数据或整个层的数据
        """
        if pop_name not in self.pops_data:
            raise ValueError(f"Layer '{pop_name}' does not exist.")

        if data_key:
            return self.pops_data[pop_name].get(data_key, None)
        else:
            return self.pops_data[pop_name]


def set_pops_data(pops_data: dict):
    pops_data_config = PopsDataConfig()
    pops_data_config.set_pops_data(pops_data)
